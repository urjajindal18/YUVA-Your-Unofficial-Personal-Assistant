<?php

do_action('mptt_shortcode_template_before_content');

do_action('mptt_shortcode_template_content');

do_action('mptt_shortcode_template_after_content');

