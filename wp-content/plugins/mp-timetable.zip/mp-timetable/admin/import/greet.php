<div class="narrow">
	<p><?php _e('Choose a WXR (.xml) file to upload, then click Upload file and import.', 'mp-timetable') ?></p>
	<?php wp_import_upload_form('admin.php?import=mptt-importer&amp;step=1') ?>
</div>