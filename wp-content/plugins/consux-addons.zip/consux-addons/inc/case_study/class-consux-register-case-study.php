<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Class register taxonomies and metaboxes
 */

if ( ! class_exists( 'Consux_Register_Case_Study' ) )
{
    class Consux_Register_Case_Study
    {

        /**
         * Consux_Register_Case_Study constructor
         */
        function __construct()
        {
            add_action( 'init', array( $this, 'case_study' ), 5 );
            add_action( 'init', array( $this, 'register_taxonomy_category' ), 5 );
        }

        /**
         * Register case_study post type
         */
        function case_study()
        {
            $labels = array(
                'name'               => _x( 'Case Studies', 'post type general name', 'consux' ),
                'singular_name'      => _x( 'Case Study', 'post type singular name', 'consux' ),
                'menu_name'          => _x( 'Case Studies', 'admin menu', 'consux' ),
                'name_admin_bar'     => _x( 'Case Study', 'add new on admin bar', 'consux' ),
                'add_new'            => _x( 'Add New', 'consux' ),
                'add_new_item'       => __( 'Add New Case Study', 'consux' ),
                'new_item'           => __( 'New Case Study', 'consux' ),
                'edit_item'          => __( 'Edit Case Study', 'consux' ),
                'view_item'          => __( 'View Case Study', 'consux' ),
                'all_items'          => __( 'All Case Studies', 'consux' ),
                'search_items'       => __( 'Search Case Studies', 'consux' ),
                'parent_item_colon'  => __( 'Parent Case Studies:', 'consux' ),
                'not_found'          => __( 'No Case Studies found.', 'consux' ),
                'not_found_in_trash' => __( 'No Case Studies found in Trash.', 'consux' )
            );

            $args = array(
                'labels'             => $labels,
                'description'        => __( 'Description.', 'consux' ),
                'public'             => true,
                'publicly_queryable' => true,
                'menu_icon'          => 'dashicons-screenoptions',
                'show_ui'            => true,
                'show_in_menu'       => true,
                'query_var'          => true,
                'rewrite'            => array( 'slug' => 'case_study' ),
                'capability_type'    => 'post',
                'has_archive'        => true,
                'hierarchical'       => false,
                'menu_position'      => null,
                'supports'           => array( 'title', 'editor','thumbnail', 'excerpt' )
            );
	        $args = apply_filters( 'consux_case_study_args', $args );
            register_post_type( 'case_study', $args );
        }

        /**
         * Function register collection taxonomy
         */
        function register_taxonomy_category()
        {
            register_taxonomy( 'case_study_categories',
               'case_study',
                apply_filters( 'consux_taxonomy_args_case_study_category', array(
                    'hierarchical'          => true,
                    'label'                 => __( 'Case Study Categories', 'consux' ),
                    'labels' => array(
                        'name'              => __( 'Case Study Categories', 'consux' ),
                        'singular_name'     => __( 'Case Study Category', 'consux' ),
                        'menu_name'         => _x( 'Case Studies Categories', 'Admin menu name', 'consux' ),
                        'search_items'      => __( 'Search Case Study Categories', 'consux' ),
                        'all_items'         => __( 'All Case Study Categories', 'consux' ),
                        'parent_item'       => __( 'Parent Case Study Category', 'consux' ),
                        'parent_item_colon' => __( 'Parent Case Study Category:', 'consux' ),
                        'edit_item'         => __( 'Edit Case Study Category', 'consux' ),
                        'update_item'       => __( 'Update Case Study Category', 'consux' ),
                        'add_new_item'      => __( 'Add New Case Study Category', 'consux' ),
                        'new_item_name'     => __( 'New Case Study Category Name', 'consux' ),
                        'not_found'         => __( 'No Case Study Category found', 'consux' ),
                    ),
                    'show_ui'               => true,
                    'query_var'             => true,
                    'rewrite'               => array(
                        'slug'         => 'case-study-category',
                    ),
                ) )
            );
        }

    }
}