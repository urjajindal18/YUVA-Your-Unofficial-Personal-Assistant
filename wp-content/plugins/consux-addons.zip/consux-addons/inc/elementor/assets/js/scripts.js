(
    function ($)
    {
        'use strict';

        var memberCarousel = function( $scope, $ )
        {
            var $constainer = $scope.find( '.member-container' );
            if ( $constainer.hasClass( 'layout-carousel' ) )
            {
                $constainer.find( '.members' ).not('.slick-initialized').slick({
                    arrows: false,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: false,
                    swipeToSlide: true,
                    dots : true,
                    responsive: [
                        {
                            breakpoint: 480,
                            settings: {
                                slidesToShow: 1
                            }
                        },
                        {
                            breakpoint: 767,
                            settings: {
                                slidesToShow: 2
                            }
                        }
                    ]
                });
            }
        }

        var caseStudyFilter = function ( $scope, $ )
        {
            var $constainer = $scope.find( '.case-studies-container' );
            $constainer.find( '.filter' ).on( 'click', function (e)
            {
                e.preventDefault();
                var $current = $( this ),
                    $grid = $constainer.find( '.case-studies' ),
                    $filterValue = '*';
                $constainer.find( '.filter' ).removeClass( 'active' );
                $current.addClass( 'active' );
                if ( '*' == $current.data( 'filter' ) )
                {
                    $filterValue = '*';
                }
                else
                {
                    $filterValue = '.' + $current.data( 'filter' );
                }
                $grid.isotope({ filter: $filterValue });
            } );
            if ( $constainer.hasClass('layout-carousel') )
            {
                var $dot = $constainer.data('hidePagination');
                var $autoplay = $constainer.data('autoplay');

                $constainer.find( '.case-studies' ).not('.slick-initialized').slick({
                    arrows: false,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: false,
                    swipeToSlide: true,
                    autoplay: $autoplay,
                    dots : $dot,
                    responsive: [
                        {
                            breakpoint: 600,
                            settings: {
                                slidesToShow: 1
                            }
                        },
                        {
                            breakpoint: 991,
                            settings: {
                                slidesToShow: 2
                            }
                        }
                    ]
                });
            }
            if ( $constainer.hasClass('layout-carousel-filter') )
            {
                var $dot = $constainer.data('hidePagination');
                var $autoplay = $constainer.data('autoplay');

                $constainer.find( '.case-studies' ).not('.slick-initialized').slick({
                    arrows: false,
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    infinite: true,
                    swipeToSlide: true,
                    autoplay: $autoplay,
                    dots : $dot,
                    responsive: [
                        {
                            breakpoint: 479,
                            settings: {
                                slidesToShow: 1
                            }
                        },
                        {
                            breakpoint: 577,
                            settings: {
                                slidesToShow: 2
                            }
                        },
                        {
                            breakpoint: 767,
                            settings: {
                                slidesToShow: 3
                            }
                        },
                        {
                            breakpoint: 991,
                            settings: {
                                slidesToShow: 4
                            }
                        }
                    ]
                });

                // Filter Case Studies
                $constainer.find( '.filter-item' ).on( 'click', function ( e ) {
                    e.preventDefault();
                    $constainer.find( '.filter-item' ).removeClass( 'active' );
                    var $current = $( this ),
                        $value = $current.data( 'value' );

                    $current.addClass( 'active' )
                    $constainer.find( '.case-studies' ).slick('slickUnfilter');
                    if ( $value != 'all' )
                    {
                        var filter = '.' + $value;
                        $constainer.find( '.case-studies' ).slick('slickFilter', filter );
                    }
                } );
            }
        };

        var videoPopup = function ( $scope, $ )
        {
            $scope.find( '.play-link' ).magnificPopup({
                disableOn: 700,
                type: 'iframe',
                mainClass: 'mfp-fade',
                removalDelay: 160,
                preloader: false,
                fixedContentPos: false
            });
        };

        var testimonialCarousel = function( $scope, $ ) 
        {
            var $container = $scope.find( '.consux-testimonial-container' );
            if ( $container.hasClass( 'layout-1' ) )
            {
                var $testimonials = $container.find( '.tesimonials' );
                var $nav = $testimonials.data('hideNavigation');
                var $autoplay = $testimonials.data('autoplay');
                $testimonials.not('.slick-initialized').slick({
                    arrows: $nav,
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: false,
                    swipeToSlide: true,
                    dots : false,
                    autoplay: $autoplay,
                    prevArrow: '<span class="slick-prev"><i class="zmdi zmdi-long-arrow-left"></i></span>',
                    nextArrow: '<span class="slick-next"><i class="zmdi zmdi-long-arrow-right"></i></span>'
                });
            }
            else if ( $container.hasClass( 'layout-3' ) )
            {
                var $testimonials = $container.find( '.tesimonials' );
                var $nav = $testimonials.data('hidePagination');
                var $autoplay = $testimonials.data('autoplay');
                $testimonials.not('.slick-initialized').slick({
                    arrows: false,
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: false,
                    swipeToSlide: true,
                    dots : $nav,
                    autoplay: $autoplay,
                    responsive: [
                        {
                            breakpoint: 767,
                            settings: {
                                slidesToShow: 1
                            }
                        }
                    ]
                });
            }
            else if ( $container.hasClass( 'layout-4' ) )
            {
                var $testimonials = $container.find( '.tesimonials' ),
                    $sliderNav = $container.find( '.slider-nav' );
                $testimonials.slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: false,
                    fade: true,
                    asNavFor: '.slider-nav'
                });
                $sliderNav.slick({
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    asNavFor: '.tesimonials',
                    dots: false,
                    arrows: false,
                    centerMode: true,
                    centerPadding: 0,
                    focusOnSelect: true,
                    responsive: [
                        {
                            breakpoint: 991,
                            settings: {
                                slidesToShow: 1,
                                centerMode: false,
                                autoplay: true
                            }
                        }
                    ]
                });
            }
        };

        var services = function( $scope, $ )
        {
            var $container = $scope.find( '.consux-service' );
            if ( $container.hasClass( 'list-carousel' ) )
            {
                var $services = $container.find( '.services' );
                var $nav = $container.data('hideNavigation');
                var $infinite = $container.data('loop');
                var $autoplay = $container.data('autoplay');
                $services.not('.slick-initialized').slick({
                    arrows: $nav,
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    infinite: $infinite,
                    swipeToSlide: true,
                    dots : false,
                    autoplay: $autoplay,
                    prevArrow: '<span class="slick-prev"><i class="zmdi zmdi-long-arrow-left"></i></span>',
                    nextArrow: '<span class="slick-next"><i class="zmdi zmdi-long-arrow-right"></i></span>',
                    responsive: [
                        {
                            breakpoint: 1199,
                            settings: {
                                slidesToShow: 3
                            }
                        },
                        {
                            breakpoint: 767,
                            settings: {
                                slidesToShow: 2
                            }
                        },
                        {
                            breakpoint: 577,
                            settings: {
                                slidesToShow: 1
                            }
                        }
                    ]
                });
            }
            else if ( $container.hasClass( 'grid-layout' ) && $container.hasClass( 'enable-carousel' ) )
            {
                var $services = $container.find( '.services' );
                var $pagination = $container.data('hidePagination');
                var $autoplay = $container.data('autoplay');
                var $infinite = $container.data('loop');
                $services.not('.slick-initialized').slick({
                    arrows: false,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: $infinite,
                    swipeToSlide: true,
                    dots : $pagination,
                    autoplay: $autoplay,
                    responsive: [
                        {
                            breakpoint: 991,
                            settings: {
                                slidesToShow: 2
                            }
                        },
                        {
                            breakpoint: 566,
                            settings: {
                                slidesToShow: 1
                            }
                        }
                    ]
                });
            }
        };

        var progressBar = function ( $scope, $ )
        {

            $(window).on('scroll', function () {
                var $progress = $scope.find( '.progress-bar' );
                if ( $progress.is( ':in-viewport' ) && ! $progress.hasClass( 'loaded' ) )
                {
                    $progress.animate({
                        width: $progress.attr( 'aria-valuenow' ) + '%'
                    }, 1000).addClass( 'loaded' );
                }
            });
        };

        var gallery = function ( $scope, $ )
        {
            var $container = $scope.find( '.grid' );
            var $grid = $container.masonry({
                // options...
            });
            // init Masonry
            // layout Masonry after each image loads
            $grid.imagesLoaded().progress( function() {
                $grid.masonry('layout');
            });

            //load photoswipe
            var $images = $grid.find('.grid-item');

            if ( !$images.length ) {
                return;
            }
    
            var $links = $images.find( '.photoswipe' ),
                items = [];
    
            $links.each( function () {
                var $this = $( this ),
                    $w = $this.attr( 'data-width' ),
                    $h = $this.attr( 'data-height' );
    
                items.push( {
                    src: $this.data( 'link' ),
                    w  : $w,
                    h  : $h
                } );
    
            } );

            $images.on( 'click', '.photoswipe', function ( e ) {
                e.preventDefault();
    
                var index = $links.index( $( this ) ),
                    options = {
                        index              : index,
                        bgOpacity: 0.85,
                        showHideOpacity: true
                    };
    
                var lightBox = new PhotoSwipe( document.getElementById( 'pswp' ), window.PhotoSwipeUI_Default, items, options );
                lightBox.init();
            } );
        };

        var countDown = function ( $scope, $ )
        {
            var $container = $scope.find('.consux-countdown-container'),
                $comingTime= $container.data('date');

            if ( $comingTime === '' )
            {
                return;
            }

            var comingDate = $comingTime;
            var $id = $container.attr('id');
            console.log( $id );

            var timer = function() {};
            timer.countdownDate = new Date( comingDate );

            /*
             * Get thing started
             */
            timer.init = function() {
                timer.getReferences( $id );
                timer.getTimes();
                setInterval(function() { timer.update(); }, 1000);
            };

            /*
             * Save references of timer section
             */
            timer.getReferences = function( $id ) {
                timer.timer = document.getElementById($id);
                timer.days = timer.timer.querySelectorAll( '.days .timer__number' )[0];
                timer.hours = timer.timer.querySelectorAll( '.hours .timer__number' )[0];
                timer.minutes = timer.timer.querySelectorAll( '.minutes .timer__number' )[0];
                timer.seconds = timer.timer.querySelectorAll( '.seconds .timer__number' )[0];
            };

            /*
             * remember time units for later use
             */
            timer.getTimes = function() {
                timer.times = {};
                timer.times.second = 1000;
                timer.times.minute = timer.times.second * 60;
                timer.times.hour = timer.times.minute * 60;
                timer.times.day = timer.times.hour * 24;
            };

            /*
             * Update the countdown
             */
            timer.update = function() {
                if ( timer.timer.style.opacity !== 1 ) {
                    timer.timer.style.opacity = 1;
                }

                timer.currentDate = new Date();
                timer.difference = timer.countdownDate - timer.currentDate;

                timer.days.innerHTML = timer.getTimeRemaining(timer.times.day, 1);
                timer.hours.innerHTML = timer.getTimeRemaining(timer.times.hour, 24);
                timer.minutes.innerHTML = timer.getTimeRemaining(timer.times.minute, 60);
                timer.seconds.innerHTML = timer.getTimeRemaining(timer.times.second, 60);
            };

            /*
             * calculate remaining time based on a unit of time
             */
            timer.getTimeRemaining = function( timeUnit, divisor ) {
                var n;
                if ( divisor == 1 ) {
                    n = Math.floor(timer.difference / timeUnit );
                }
                else {
                    n = Math.floor((timer.difference / timeUnit) % divisor );
                }

                if ( String(n).length < 2 ) {
                    n = '0' + n;
                }

                return n;
            };

            window.addEventListener( 'load' , function() {
                timer.init();
            });

        };

        var iconBox = function ( $scope, $ )
        {
            var $counter = $scope.find( '.counter' ),
                $toValue = $counter.data( 'valueTo' );
            $(window).on('scroll', function () {
                if ( $counter.is( ':in-viewport' ) )
                {
                    $counter.numerator({
                        duration: 2000,
                        toValue: $toValue
                    });
                }
            } );
        };

        var imagesCarousel = function ( $scope, $ )
        {
            var $imgContainer = $scope.find('.consux-images.layout-1');
            var $dot = $imgContainer.data('hidePagination');
            var $autoplay = $imgContainer.data('autoplay');
            var $slideToShow = $imgContainer.data('columns');;
            $imgContainer.find( '.images' ).not('.slick-initialized').slick({
                arrows: false,
                slidesToShow: $slideToShow,
                slidesToScroll: 1,
                infinite: false,
                swipeToSlide: true,
                dots : $dot,
                autoplay: $autoplay,
                responsive: [
                    {
                        breakpoint: 991,
                        settings: {
                            slidesToShow: $slideToShow -1
                        }
                    },
                    {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: $slideToShow -2
                        }
                    },
                    {
                        breakpoint: 577,
                        settings: {
                            slidesToShow: 3
                        }
                    },
                    {
                        breakpoint: 379,
                        settings: {
                            slidesToShow: 1
                        }
                    }
                ]
            });
        };

        $(window).on('elementor/frontend/init', function ()
        {

            if (elementorFrontend.isEditMode()) {
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_case_study.default', caseStudyFilter );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_video_button.default', videoPopup );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_progress.default', progressBar );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_testimonial.default', testimonialCarousel );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_member.default', memberCarousel );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_gallery.default', gallery );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_countdown.default', countDown );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_icon_box.default', iconBox );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_service.default', services );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_images.default', imagesCarousel );
            }
            else {
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_case_study.default', caseStudyFilter );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_video_button.default', videoPopup );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_progress.default', progressBar );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_testimonial.default', testimonialCarousel );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_member.default', memberCarousel );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_gallery.default', gallery );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_countdown.default', countDown );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_icon_box.default', iconBox );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_service.default', services );
                elementorFrontend.hooks.addAction('frontend/element_ready/consux_images.default', imagesCarousel );
            }
        });
    }
)( jQuery );