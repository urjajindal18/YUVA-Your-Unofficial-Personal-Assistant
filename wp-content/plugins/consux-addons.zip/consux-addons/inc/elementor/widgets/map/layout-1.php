<?php
$id = uniqid( 'google-map-' );
$zoom = $settings['zoom'];
$scroll = ! empty( $settings['prevent_scroll'] ) ? 'true' : 'false';
$key = $settings['api'];
$marker =$settings['marker'];
$locations[] = array(
	'lat'   =>  $settings['lat'],
	'lng'   =>  $settings['lng']
);
?>
<div class="consux-google-map-container">
	<div id="<?php echo esc_attr( $id ); ?>" class="consux-map"></div>
</div>
<script>
	function initMap()
	{
		var mapDiv = document.getElementById('<?php echo esc_attr($id); ?>');
		var firstLocationLat = <?php echo esc_attr($locations[0]['lat']); ?>;
		var firstLocationLong = <?php echo esc_attr($locations[0]['lng']); ?>;

		window.map = new google.maps.Map(mapDiv, {
			center: {lat: firstLocationLat, lng:  firstLocationLong},
			zoom: <?php echo $zoom['size']; ?>,
			scrollwheel: <?php echo $scroll; ?>,
			styles: [
				{
					"elementType": "geometry",
					"stylers": [
						{
							"color": "#f5f5f5"
						}
					]
				},
				{
					"elementType": "labels.icon",
					"stylers": [
						{
							"visibility": "off"
						}
					]
				},
				{
					"elementType": "labels.text.fill",
					"stylers": [
						{
							"color": "#616161"
						}
					]
				},
				{
					"elementType": "labels.text.stroke",
					"stylers": [
						{
							"color": "#f5f5f5"
						}
					]
				},
				{
					"featureType": "administrative.land_parcel",
					"elementType": "labels.text.fill",
					"stylers": [
						{
							"color": "#bdbdbd"
						}
					]
				},
				{
					"featureType": "poi",
					"elementType": "geometry",
					"stylers": [
						{
							"color": "#eeeeee"
						}
					]
				},
				{
					"featureType": "poi",
					"elementType": "labels.text.fill",
					"stylers": [
						{
							"color": "#757575"
						}
					]
				},
				{
					"featureType": "poi.park",
					"elementType": "geometry",
					"stylers": [
						{
							"color": "#e5e5e5"
						}
					]
				},
				{
					"featureType": "poi.park",
					"elementType": "labels.text.fill",
					"stylers": [
						{
							"color": "#9e9e9e"
						}
					]
				},
				{
					"featureType": "road",
					"elementType": "geometry",
					"stylers": [
						{
							"color": "#ffffff"
						}
					]
				},
				{
					"featureType": "road.arterial",
					"elementType": "labels.text.fill",
					"stylers": [
						{
							"color": "#757575"
						}
					]
				},
				{
					"featureType": "road.highway",
					"elementType": "geometry",
					"stylers": [
						{
							"color": "#dadada"
						}
					]
				},
				{
					"featureType": "road.highway",
					"elementType": "labels.text.fill",
					"stylers": [
						{
							"color": "#616161"
						}
					]
				},
				{
					"featureType": "road.local",
					"elementType": "labels.text.fill",
					"stylers": [
						{
							"color": "#9e9e9e"
						}
					]
				},
				{
					"featureType": "transit.line",
					"elementType": "geometry",
					"stylers": [
						{
							"color": "#e5e5e5"
						}
					]
				},
				{
					"featureType": "transit.station",
					"elementType": "geometry",
					"stylers": [
						{
							"color": "#eeeeee"
						}
					]
				},
				{
					"featureType": "water",
					"elementType": "geometry",
					"stylers": [
						{
							"color": "#c9c9c9"
						}
					]
				},
				{
					"featureType": "water",
					"elementType": "labels.text.fill",
					"stylers": [
						{
							"color": "#9e9e9e"
						}
					]
				}
			]
		});

		var iconUrl = '<?php echo esc_url( $marker['url'] ); ?>';
		var locations = <?php echo json_encode( $locations ); ?>;
		for ( var i = 0; i < locations.length; i++ )
		{
			var marker = new google.maps.Marker({
				position: new google.maps.LatLng( locations[i]['lat'], locations[i]['lng'] ),
				icon: iconUrl,
				map: window.map
			});
		}

	}
</script>
<script async defer
        src="https://maps.googleapis.com/maps/api/js?sensor=false&key=<?php echo esc_attr( $key ); ?>&callback=initMap">
</script>