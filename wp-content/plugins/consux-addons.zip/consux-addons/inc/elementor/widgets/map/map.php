<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class Consux_Map_Widget extends Widget_Base {

	public function get_name()
	{
		return 'consux_map';
	}

	public function get_title()
	{
		return esc_html__('Map', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-google-maps';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		// Content Tab
		$this->tab_content();
		// Tab Style
//		$this->tab_style();
	}

	// section and element on tab content
	private function tab_content ()
	{
		$this->start_controls_section(
			'section_map',
			[
				'label' => __( 'Map', 'consux' ),
			]
		);

		$default_address = __( 'London Eye, London, United Kingdom', 'consux' );

		$this->add_control(
			'api',
			[
				'label' => __( 'API key', 'consux' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Input your google map api key here' ),
				'description' => esc_html__( 'Input here the API key to display google map, you can register it at: ', 'consux' ) . '<a target="_blank" href="https://developers.google.com/maps/documentation/javascript/get-api-key">Here</a>',
				'label_block' => true,
			]
		);

		$this->add_control(
			'lat',
			[
				'label' => __( 'Lat', 'consux' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => '51.5033273',
				'default' => '51.5033273',
				'label_block' => true,
			]
		);

		$this->add_control(
			'lng',
			[
				'label' => __( 'Lng', 'consux' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => '-0.1217317',
				'default' => '-0.1217317',
				'label_block' => true,
			]
		);
		$this->add_control(
			'detail',
			[
				'label' => __( 'Detail', 'consux' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => $default_address,
				'default' => $default_address,
				'label_block' => true,
			]
		);
		$this->add_control(
			'marker',
			[
				'label' => __( 'Choose Marker', 'consux' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => CONSUX_TF_INC_URL . 'elementor/assets/img/marker.png',
				],
			]
		);
		$this->add_control(
			'zoom',
			[
				'label' => __( 'Zoom', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 10,
				],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 20,
					],
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label' => __( 'Height', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'size_units'    =>  ['px','%'],
				'range' => [
					'px' => [
						'min' => 40,
						'max' => 1440,
					],
					'%' => [
						'min' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-google-map-container .consux-map' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'prevent_scroll',
			[
				'label' => __( 'Prevent Scroll', 'consux' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'true',
			]
		);

		$this->end_controls_section();
	}

	// section and element on tab style
	private function tab_style()
	{
		$this->start_controls_section(
			'section_style',
			[
				'label' =>  esc_html__( 'Content', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_primary_color',
			[
				'label' => __( 'Title Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .entry-title a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .case-studies-container.layout-1 article .outer .entry-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Title Typography' ),
				'name'  =>  'title_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .entry-title a',
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->add_responsive_control(
			'title_space_down',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 34,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .entry-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'(mobile){{WRAPPER}} .case-studies-container.layout-1 article .outer .info .entry-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => esc_html__( 'Button Color', 'consux' ),
				'type'  =>  Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .button' => 'color: {{VALUE}};',
				],
				'default'   =>  '#7eb729',
				'condition'	=>	[
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Button Typography' ),
				'name'  =>  'button_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .button',
				'condition'	=>	[
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) . '/layout-1.php';
	}

}

$widgets_manager->register_widget_type(new \Consux_Map_Widget());