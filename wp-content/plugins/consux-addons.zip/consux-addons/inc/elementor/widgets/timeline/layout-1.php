<?php
$lines = $settings['lines'];
if ( count( $lines ) < 1 )
{
    return;
}
?>
<div class="consux-timeline-container <?php echo esc_attr( $settings['layout'] ); ?>">
    <div class="timelines">
    <?php
    foreach( $lines as $line )
    {
    ?>
        <div class="timeline">
            <span class="dots"><span class="dot1"></span></span>
            <h3><span class="time"><?php echo esc_html( $line['time'] ); ?></span><span class="title"><?php echo esc_html( $line['title'] ); ?></span></h3>
            <p class="description">
                <?php echo esc_html( $line['info'] ); ?>
            </p>
        </div>
    <?php
    }
    ?>
    </div>
</div>