<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class Consux_TimeLine_Widget extends Widget_Base {

	public function get_name()
	{
		return 'consux_timeline';
	}

	public function get_title()
	{
		return esc_html__('TimeLine', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-time-line';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		// Content Tab
		$this->tab_content();
		// Tab Style
		 $this->tab_style();
	}

	// section and element on tab content
	private function tab_content ()
	{
		$this->start_controls_section(
			'case_study_step_info',
			[
				'label' => __('TimeLine', 'consux'),
			]
		);
		$this->add_control(
			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'label_block' => true,
				'default'   =>  'layout-1',
				'options' => [
					'layout-1' => __('Layout 1', 'consux'),
				],
			]
		);
		
		$repeater = new Elementor\Repeater();

		$repeater->add_control(
			'time',
			[
				'label' =>  esc_html__( 'Time', 'consux' ),
				'type'  =>  Controls_Manager::TEXT
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' =>  esc_html__( 'Title', 'consux' ),
				'type'  =>  Controls_Manager::TEXT
			]
		);

		$repeater->add_control(
			'info',
			[
				'label' =>  esc_html__( 'Information', 'consux' ),
				'type'  =>  Controls_Manager::TEXTAREA,
				'default'   =>  '',
			]
		);

		$this->add_control(
			'lines',
			[
				'label' =>   esc_html__( 'Time Lines', 'consux' ),
				'type'  =>  Controls_Manager::REPEATER,
				'fields'    =>  $repeater->get_controls(),
				'default'   =>
				[
					[
						'time'	=>	esc_html__( '#1 Timeline Title' ),
						'info'   =>  esc_html__( 'Input Description for timeline here' )
					]
				]
			]
		);

		$this->end_controls_section();
	}

	// section and element on tab style
	private function tab_style()
	{
		$this->start_controls_section(
			'section_style',
			[
				'label' =>  esc_html__( 'Infomation', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		// Name Style

		$this->add_control(
			'time_color',
			[
				'label' => __( 'Time Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-timeline-container .timelines .timeline h3 .time' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#222',
				'selectors' => [
					'{{WRAPPER}} .consux-timeline-container .timelines .timeline h3' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography' ),
				'name'  =>  'title_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-timeline-container .timelines .timeline h3',
			]
		);

		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => esc_html__( 'Title Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 31,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator'	=>	'after',
				'selectors' => [
					'{{WRAPPER}} .consux-timeline-container .timelines .timeline h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

	// Description Style

		$this->add_control(
			'desc_color',
			[
				'label' => __( 'Description Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#777',
				'selectors' => [
					'{{WRAPPER}} .consux-timeline-container .timelines .timeline .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography' ),
				'name'  =>  'description_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-timeline-container .timelines .timeline .description',
			]
		);

		// Timeline Style

			$this->add_control(
			'dot_color',
			[
				'label' => __( 'Dot Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-timeline-container .timelines .timeline .dots' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'line_spacing',
			[
				'label' => esc_html__( 'Timeline Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 54,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-timeline-container .timelines .timeline + .timeline' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) . '/' . $settings['layout'] .'.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_TimeLine_Widget());