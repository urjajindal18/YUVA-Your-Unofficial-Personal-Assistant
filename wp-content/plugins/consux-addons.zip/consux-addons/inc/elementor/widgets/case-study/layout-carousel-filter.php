<?php
$case_studies = consux_get_case_study( $settings );
?>
<div class="case-studies-container layout-carousel-filter carousel-dot-style-circle" data-autoplay="<?php echo esc_attr( empty( $settings['carousel_autoplay'] ) ? 'false' : 'true' ); ?>" data-hide-pagination="<?php echo esc_attr( empty( $settings['hide_pagination'] ) ? 'true' : 'false' ); ?>">
	<div class="container top-bar">
		<div class="row align-items-end">
			<div class="col-lg-5 left-side">
				<h3><?php echo esc_html( $settings['section_title'] ); ?></h3>
				<div class="sub-title">
					<span class="sub"><?php echo esc_html( $settings['section_sub_title'] ); ?></span>
					<span class="line"></span>
				</div>
			</div>
			<div class="col-lg-7 right-side d-none d-md-block">
				<ul class="list-categories d-flex justify-lg-content-end justify-content-center">
					<li><a href="#" class="filter-item active" data-value="all"><?php esc_html_e( 'All', 'butler' ); ?></a></li>
					<?php
					$cats = consux_get_list_case_study_categories();
					foreach ( $cats as $key => $value )
					{
						?>
						<li><a href="#" class="filter-item" data-value="<?php echo sprintf( 'case_study_categories-%s', esc_attr( $key ) ); ?>"><?php echo esc_html( $value ); ?></a></li>
						<?php
					}
					?>
				</ul>
			</div>
		</div>
	</div>
<?php
if ( $case_studies )
{
	echo '<div class="case-studies">';
	while ($case_studies->have_posts()) : $case_studies->the_post();
	?>
		<article <?php post_class(); ?>>
			<div class="outer">
			<?php
			if ( has_post_thumbnail() )
			{
			?>
			<div class="thumbnail hover-zoomin">
				<a href="<?php the_permalink(); ?>">
				<?php
				$image_id = get_post_thumbnail_id();
				$image = tz_get_image_custom_size_html( $image_id, 384, 260 );
				if ( $image )
				{
					echo $image;
				}
				?>
				</a>
			</div>
			<?php
			}
			?>
				<div class="info">
					<h3 class="entry-title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
					<?php
					$id = get_the_ID();
					$cats = get_the_terms( $id, 'case_study_categories' );
					if ( $cats )
					{
						?>
						<div class="categories">
							<?php
							$count = 0;
							foreach ( $cats as $cat )
							{
								$separator = ', ';
								if ( $count == count( $cats ) - 1 )
								{
									$separator = '';
								}
								echo sprintf( '<a class="cat" href="%s">%s%s</a>', get_term_link( $cat->term_id ), esc_html( $cat->name ), $separator );
								$count++;
							}
							?>
						</div>
						<?php
					}
					?>
				</div>
			</div>
		</article>
	<?php
	endwhile;
	wp_reset_postdata();
	echo '</div>';
}
?>
</div>