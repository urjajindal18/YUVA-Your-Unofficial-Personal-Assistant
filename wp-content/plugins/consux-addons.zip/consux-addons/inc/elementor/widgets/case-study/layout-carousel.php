<?php
$case_studies = consux_get_case_study( $settings );
?>
<div class="case-studies-container layout-carousel carousel-dot-style-circle" data-autoplay="<?php echo esc_attr( empty( $settings['carousel_autoplay'] ) ? 'false' : 'true' ); ?>" data-hide-pagination="<?php echo esc_attr( empty( $settings['hide_pagination'] ) ? 'true' : 'false' ); ?>">
<?php
if ( $case_studies )
{
	echo '<div class="case-studies row">';
	while ($case_studies->have_posts()) : $case_studies->the_post();
		$col = 'col-md-4';
	?>
		<article <?php post_class( $col ); ?>>
			<div class="outer">
			<?php
			if ( has_post_thumbnail() )
			{
			?>
			<div class="thumbnail">
				<?php
				$image_id = get_post_thumbnail_id();
				$image = tz_get_image_custom_size_html( $image_id, 370, 431 );
				if ( $image )
				{
					echo $image;
				}
				?>
			</div>
			<?php
			}
			?>
				<div class="info">
					<?php
					$id = get_the_ID();
					$cats = get_the_terms( $id, 'case_study_categories' );
					if ( $cats )
					{
					?>
						<div class="categories">
						<?php
						$count = 0;
						foreach ( $cats as $cat )
						{
							$separator = ', ';
							if ( $count == count( $cats ) - 1 )
							{
								$separator = '';
							}
							echo sprintf( '<a class="cat" href="%s">%s%s</a>', get_term_link( $cat->term_id ), esc_html( $cat->name ), $separator );
							$count++;
						}
						?>
						</div>
					<?php
					}
					?>
					<h3 class="entry-title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
					<a class="button" href="<?php the_permalink()?>"><?php esc_html_e( 'read more', 'consux' ); ?><i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
				</div>
			</div>
		</article>
	<?php
	endwhile;
	wp_reset_postdata();
	echo '</div>';
}
?>
</div>