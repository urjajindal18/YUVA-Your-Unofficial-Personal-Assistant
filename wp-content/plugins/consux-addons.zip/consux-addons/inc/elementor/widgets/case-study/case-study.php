<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class Consux_Case_Study_Widget extends Widget_Base {

	public function get_name()
	{
		return 'consux_case_study';
	}

	public function get_title()
	{
		return esc_html__('Case Study', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-posts-grid';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		// Content Tab
		$this->tab_content();
		// Tab Style
		$this->tab_style();
	}

	// section and element on tab content
	private function tab_content ()
	{
		$this->start_controls_section(
			'case_study_step_info',
			[
				'label' => __('Case Study', 'consux'),
			]
		);
		$this->add_control(
			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'label_block' => true,
				'default'   =>  'layout-1',
				'options' => [
					'layout-1' => esc_html__('Grid', 'consux'),
					'layout-grid-2' => esc_html__('Grid 2', 'consux'),
					'layout-carousel' => esc_html__('Carousel', 'consux'),
					'layout-carousel-filter' => esc_html__('Carousel Filter', 'consux'),
				],
			]
		);
		$this->add_control(
			'section_title',
			[
				'label' =>  esc_html__( 'Heading', 'consux' ),
				'type'  =>  Controls_Manager::TEXT,
				'default'   =>  esc_html__( 'OUR PROJECTS', 'consux' ),
				'condition' =>  [
					'layout'    =>  'layout-carousel-filter'
				]
			]
		);
		$this->add_control(
			'section_sub_title',
			[
				'label' =>  esc_html__( 'Sub Heading', 'consux' ),
				'type'  =>  Controls_Manager::TEXT,
				'default'   =>  esc_html__( 'Case Studies', 'consux' ),
				'condition' =>  [
					'layout'    =>  'layout-carousel-filter'
				]
			]
		);
		$this->add_control(
			'per_page',
			[
				'label' => esc_html__( 'Number Case Study Show', 'consux' ),
				'type'  => Controls_Manager::NUMBER,
				'min'   => -1,
				'step'  => 1,
				'default'   => 12
			]
		);

		$this->add_control(
			'carousel_autoplay',
			[
				'label'	=> esc_html__( 'Autoplay','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  [ 'layout-carousel', 'layout-carousel-filter' ]
				]
			]
		);

		$this->add_control(
			'hide_pagination',
			[
				'label'	=> esc_html__( 'Hide Pagination','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  [ 'layout-carousel', 'layout-carousel-filter' ]
				]
			]
		);

		$this->end_controls_section(); // End section Info

		$this->start_controls_section(
			'case_study_query',
			[
				'label' =>  esc_html__( 'Query', 'consux' ),
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' => __( 'Order By', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'post_date',
				'options' => [
					'post_date' => __( 'Date', 'consux' ),
					'post_title' => __( 'Title', 'consux' ),
					'menu_order' => __( 'Menu Order', 'consux' ),
					'rand' => __( 'Random', 'consux' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label' => __( 'Order', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc' => __( 'ASC', 'consux' ),
					'desc' => __( 'DESC', 'consux' ),
				],
			]
		);

		$this->add_control(
			'category',
			[
				'label' => __( 'Category', 'consux' ),
				'type' => Controls_Manager::SELECT2,
				'label_block' => true,
				'default' => [],
				'options' => consux_get_list_case_study_categories(),
			]
		);

		$this->end_controls_section();
	}

	// section and element on tab style
	private function tab_style()
	{
		$this->start_controls_section(
			'section_style',
			[
				'label' =>  esc_html__( 'Content', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_primary_color',
			[
				'label' => __( 'Title Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .entry-title a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .case-studies-container.layout-1 article .outer .entry-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .case-studies-container.layout-carousel-filter .left-side h3' => 'color: {{VALUE}};',
					'{{WRAPPER}} .case-studies-container.layout-grid-2 .case-studies article .outer .info a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'layout_grid_2_cat_color',
			[
				'label' => __( 'Categories Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-grid-2 .case-studies article .outer .info .categories a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' => __( 'Sub Title Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-carousel-filter .left-side .sub-title .sub' => 'color: {{VALUE}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-carousel-filter'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Title Typography' ),
				'name'  =>  'title_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .entry-title a',
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->add_responsive_control(
			'title_space_down',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 34,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .entry-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'(mobile){{WRAPPER}} .case-studies-container.layout-1 article .outer .info .entry-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' =>  [
					'layout!'    =>  ['layout-carousel-filter','layout-grid-2']
				]
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => esc_html__( 'Button Color', 'consux' ),
				'type'  =>  Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .button' => 'color: {{VALUE}};',
				],
				'default'   =>  '#7eb729',
				'condition'	=>	[
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Button Typography' ),
				'name'  =>  'button_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .case-studies-container.layout-1 article .outer .info .button',
				'condition'	=>	[
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_filter_item_style',
			[
				'label' =>  esc_html__( 'Carousel', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
				'condition' =>  [
					'layout'    =>  'layout-carousel-filter'
				]
			]
		);

		$this->add_control(
			'name_color',
			[
				'label' => __( 'Case Study Name Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#222',
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-carousel-filter article .outer .info h3 a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'name_hover_color',
			[
				'label' => __( 'Case Study Name Hover Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-carousel-filter article .outer .info h3 a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cat_item_color',
			[
				'label' => __( 'Category Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#777',
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-carousel-filter article .outer .info .categories a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cat_item_hover_color',
			[
				'label' => __( 'Category Hover Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#777',
				'selectors' => [
					'{{WRAPPER}} .case-studies-container.layout-carousel-filter article .outer .info .categories a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) . '/' . $settings['layout'] .'.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_Case_Study_Widget());