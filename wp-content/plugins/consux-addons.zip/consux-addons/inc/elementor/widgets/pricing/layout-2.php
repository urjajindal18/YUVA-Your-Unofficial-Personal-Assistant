<?php
$is_featured = empty( $settings['featured'] ) ? '' : 'featured';
?>
<div class="consux-pricing-table-container <?php echo esc_attr( $settings['layout'] ); ?>">
	<div class="pricing_table <?php echo esc_attr( $is_featured ); ?>">
		<?php
		$header_style = '';
		if ( !empty( $settings['bg_header']['url'] ) )
		{
			$header_style = sprintf( 'style="background-image:url(%s)"', esc_url( $settings['bg_header']['url'] ) );
		}
		?>
		<h3 class="plan" <?php echo wp_kses_post( $header_style ); ?>><?php echo esc_html( $settings['plan'] ); ?></h3>
		<div class="period">
			<div class="price">
			<?php
			if ( $settings['prefix_price'] )
			{
			?>
				<span class="prefix-price"><?php echo esc_html__( $settings['prefix_price'] ); ?></span>
			<?php
			}
			?>
				<span class="plan-price"><?php echo esc_html__( $settings['price'] ); ?></span>
			</div>
			<div class="period-plan">
				<?php echo esc_html__( $settings['period'] ); ?>
			</div>
		</div>
		<ul>
		<?php
		foreach ( $settings['lines_info'] as $line )
		{
			$unmark = '';
			if ( ! empty( $line['unmark'] ) )
			{
				$unmark = sprintf( 'class="unmark"' );
			}
		?>
			<li <?php echo $unmark; ?>><span><?php echo $line['info']; ?></span></li>
		<?php
		}
		?>
		</ul>
		<div class="button">
			<a class="btn-main" href="<?php echo esc_url( $settings['button_url'] ); ?>"><?php echo esc_html( $settings['button_text'] ); ?></a>
		</div>
	</div>
</div>