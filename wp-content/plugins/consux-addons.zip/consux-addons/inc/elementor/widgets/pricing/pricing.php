<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class Consux_Pricing_Table extends Widget_Base {

	public function get_name()
	{
		return 'consux_pricing_table';
	}

	public function get_title()
	{
		return esc_html__('Pricing Table', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-price-table';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls()
	{
		$this->tab_content();
		$this->tab_style();
	}

	private function tab_content()
	{
		$this->start_controls_section(
			'section_icon_box',
			[
				'label' => esc_html__('Table', 'consux'),
			]
		);

		$this->add_control(
			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'default' => 'layout-1',
				'label_block' => true,
				'options' => [
					'layout-1' => __('Layout 1', 'consux'),
					'layout-2' => __('Layout 2', 'consux'),
				],
			]
		);

		$this->add_control(
			'plan',
			[
				'label' =>  esc_html__( 'Plan Name', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'featured',
			[
				'label' =>  esc_html__( 'Featured Plan', 'consux' ),
				'type'  =>  Controls_Manager::SWITCHER,
				'condition' =>  [
					'layout' =>  'layout-1'
				]
			]
		);

		$this->add_control(
			'bg_header',
			[
				'label' => esc_html__( 'Header Background Image', 'consux' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => CONSUX_TF_INC_URL . 'elementor/assets/img/pricing-header.png',
				],
				'condition' =>  [
					'featured' =>  'yes'
				]
			]
		);

		$this->add_control(
			'prefix_price',
			[
				'label' =>  esc_html__( 'Prefix', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
				'condition' =>  [
					'layout' =>  'layout-2'
				]
			]
		);

		$this->add_control(
			'price',
			[
				'label' =>  esc_html__( 'Price', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'period',
			[
				'label' =>  esc_html__( 'Period', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'extra',
			[
				'label' =>  esc_html__( 'Extra Text', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default'   =>  esc_html__( 'with 7 days free trail', 'consux' ),
				'label_block' => true,
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$repeater = new Elementor\Repeater();

		$repeater->add_control(
			'info',
			[
				'label' =>  esc_html__( 'Line Information', 'consux' ),
				'type'  =>  Controls_Manager::TEXT
			]
		);

		$repeater->add_control(
			'unmark',
			[
				'label' =>  esc_html__( 'UnMark', 'consux' ),
				'type'  =>  Controls_Manager::SWITCHER
			]
		);

		$this->add_control(
			'lines_info',
			[
				'label' =>  esc_html__( 'Pricing Features', 'consux' ),
				'type'  => Controls_Manager::REPEATER,
				'fields'    =>  $repeater->get_controls(),
				'default'   =>  [
					'info'  =>  esc_html__( '24h Support', 'consux' ),
				]
			]
		);

		$this->add_control(
			'button_text',
			[
				'label' =>  esc_html__( 'Button Link Text', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_url',
			[
				'label' =>  esc_html__( 'Button Link URL', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$this->end_controls_section();
	}
	private function tab_style()
	{
		$this->start_controls_section(
			'pricing_table_style',
			[
				'label' =>  esc_html__( 'Pricing Table', 'consux' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Plan Typography' ),
				'name'  =>  'plan_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-pricing-table-container .pricing_table .plan',
			]
		);

		$this->add_control(
			'plan_bg_color',
			[
				'label' => __( 'Plan Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container.layout-1 .pricing_table .plan' => 'background-color: {{VALUE}};',
				],
				'condition' =>  [
					'featured!' =>  'yes',
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->add_control(
			'plan_color',
			[
				'label' => __( 'Plan Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .plan' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'plan_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .plan' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Price Typography' ),
				'name'  =>  'price_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-pricing-table-container.layout-1 .pricing_table .period .price',
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Price Typography' ),
				'name'  =>  'price_typo_2',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-pricing-table-container.layout-2 .pricing_table .period .price .plan-price',
				'condition' =>  [
					'layout'    =>  'layout-2'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Prefix Price Typography' ),
				'name'  =>  'prefix_price_typo_2',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-pricing-table-container.layout-2 .pricing_table .period .price .prefix-price',
				'condition' =>  [
					'layout'    =>  'layout-2'
				]
			]
		);

		$this->add_control(
			'period_bg_color',
			[
				'label' => __( 'Period Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container.layout-2 .pricing_table .period' => 'background-color: {{VALUE}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-2'
				]
			]
		);

		$this->add_control(
			'period_border_color',
			[
				'label' => __( 'Period Border Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .period' => 'border-top-color: {{VALUE}};border-bottom-color: {{VALUE}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-2'
				]
			]
		);

		$this->add_control(
			'price_color',
			[
				'label' => __( 'Price Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#777',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .period .price' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Period Typography' ),
				'name'  =>  'period_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-pricing-table-container .pricing_table .period .period-plan',
			]
		);

		$this->add_control(
			'period_color',
			[
				'label' => __( 'Period Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#777',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .period .period-plan' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'price_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}}  .consux-pricing-table-container .pricing_table .period' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// extra-info

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Price Typography' ),
				'name'  =>  'extra_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-pricing-table-container.layout-1 .pricing_table .extra-info',
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->add_control(
			'extra_color',
			[
				'label' => __( 'Extra Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .extra-info' => 'color: {{VALUE}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->add_responsive_control(
			'extra_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}}  .consux-pricing-table-container .pricing_table .extra-info' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		// List Featured

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Featured Typography' ),
				'name'  =>  'featured_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-pricing-table-container .pricing_table ul',
			]
		);

		$this->add_control(
			'featured_color',
			[
				'label' => __( 'Featured Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#777',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table ul' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'featured_item_space',
			[
				'label' => esc_html__( 'Items Space ', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table ul li + li' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'featured_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}}  .consux-pricing-table-container .pricing_table ul' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Button

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Button Typography' ),
				'name'  =>  'button_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .consux-pricing-table-container .pricing_table .btn-main',
			]
		);

		$this->add_control(
			'button_bg_color',
			[
				'label' => __( 'Featured Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .btn-main' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => __( 'Button Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .btn-main' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_bg_color_hover',
			[
				'label' => __( 'Button Background Color Hover', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .btn-main:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_color_hover',
			[
				'label' => __( 'Button Color Hover', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .btn-main:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} .consux-pricing-table-container .pricing_table .btn-main' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) .'/' . $settings['layout'] . '.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_Pricing_Table());