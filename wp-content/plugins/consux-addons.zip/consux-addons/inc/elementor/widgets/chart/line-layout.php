<?php
$id = uniqid( 'consux-chart-' );
$labels = sprintf( "['%s']", str_replace( ',', "', '", $settings['data_labels']) );
$datas = array();
$titles = array();
if ( isset( $settings['list_datas'] ) )
{
	foreach ( $settings['list_datas'] as $data )
	{
		$datas[] = sprintf( '{label: "%s", data: %s, borderColor: "%s", borderWidth: 2, fill: false, lineTension: 0.1}',  '', isset( $data['data_pies'] ) ? sprintf( '[%s]', $data['data_pies'] ) : '', isset( $data['pie_color'] ) ? $data['pie_color'] : '');
		$titles[ $data['pie_color'] ] = $data['data_title'];
	}
}
?>
<div class="consux-chart line">
	<div class="labels_container d-flex justify-content-end align-items-center">
		<?php
		foreach( $titles as $key => $value )
		{
			echo sprintf( '<div><span style="background-color: %s"></span>%s</div>', esc_attr( $key ), esc_html( $value ) );
		}
		?>
	</div>
	<canvas id="<?php echo esc_attr( $id ); ?>" width="400" height="400"></canvas>
	<script>
		var ctx = document.getElementById('<?php echo $id; ?>').getContext('2d');
		var myChart = new Chart(ctx, {
			type: 'line',
			data: {
				labels: <?php echo $labels; ?>,
				datasets: [<?php echo implode(', ', $datas); ?>]
			},
			options: {
				legend: { display: false },
				scales: {
					xAxes: [{
						ticks: {
							fontSize: 14,
							fontFamily: 'Poppins',
							fontColor: '#222'
						}
					}]
				}
			}
		});
	</script>
</div>