<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class Cosnux_Chart_Widget extends Widget_Base {

	public function get_name()
	{
		return 'consux_chart';
	}

	public function get_title()
	{
		return __('Chart', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-integration';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		// Content Tab
		$this->tab_content();
	}

	// section and element on tab content
	private function tab_content ()
	{
		$this->start_controls_section(
			'section_chart',
			[
				'label' => esc_html__('Chart', 'consux'),
			]
		);

		$this->add_control(
			'type',
			[
				'type' => Controls_Manager::SELECT,
				'label' => esc_html__('Choose Type', 'consux'),
				'default' => 'layout-inline',
				'label_block' => true,
				'default'   =>  'line',
				'options' => [
					'line' => esc_html__('line', 'consux'),
				],
			]
		);

		$this->add_responsive_control(
			'chart_width',
			[
				'label' =>  esc_html__( 'Width', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'size_units'    =>  ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' =>  [
						'min' => 0,
						'max' => 100,
						'step'  =>  1
					]
				],
				'default'   =>  [
					'size' => 400,
				],
				'selectors' => [
					'{{WRAPPER}} .consux-chart canvas' => 'width: {{SIZE}}{{UNIT}} !important;',
					'(mobile){{WRAPPER}} .consux-chart canvas' => 'width: {{SIZE}}{{UNIT}} !important;',
				],
			]
		);

		$this->add_responsive_control(
			'chart_height',
			[
				'label' =>  esc_html__( 'Height', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'size_units'    =>  ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' =>  [
						'min' => 0,
						'max' => 100,
						'step'  =>  1
					]
				],
				'default'   =>  [
					'size' => 400,
				],
				'selectors' => [
					'{{WRAPPER}} .consux-chart canvas' => 'height: {{SIZE}}{{UNIT}} !important;',
					'(mobile){{WRAPPER}} .consux-chart canvas' => 'height: {{SIZE}}{{UNIT}} !important;',
				],
			]
		);

		$this->add_control(
			'data_labels',
			[
				'label' =>  esc_html__( 'Labels', 'consux' ),
				'type'  =>  Controls_Manager::TEXT,
				'placeholder' => __( 'JAN,FEB,MAR,MAY', 'consux' ),
				'description' => __( 'List datas, split by comma', 'consux' ),
				'condition'	=>	[
					'type'	=>	'line'
				]
			]
		);

		// for chart bar
		$repeater = new Elementor\Repeater();

		$repeater->add_control(
			'data_pies',
			[
				'label' =>  esc_html__( 'Datas', 'consux' ),
				'type'  =>  Controls_Manager::TEXT,
				'placeholder' => __( '10,20,15,5', 'consux' ),
				'description' => __( 'List datas, split by comma', 'consux' ),
			]
		);
		$repeater->add_control(
			'data_title',
			[
				'label' =>  esc_html__( 'Title', 'consux' ),
				'type'  =>  Controls_Manager::TEXT,
			]
		);
		$repeater->add_control(
			'pie_color',
			[
				'label' =>  esc_html__( 'Background Color', 'consux' ),
				'type'  =>  Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'   =>  '#7eb729'

			]
		);
		$this->add_control(
			'list_datas',
			[
				'label' =>  esc_html__( 'Datas', 'consux' ),
				'type'  =>  Controls_Manager::REPEATER,
				'fields'    =>  $repeater->get_controls(),
				'condition'	=>	[
					'type'	=>	'line'
				]
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) . '/' . $settings['type'] . '-layout.php';
	}

}
$widgets_manager->register_widget_type(new \Cosnux_Chart_Widget());