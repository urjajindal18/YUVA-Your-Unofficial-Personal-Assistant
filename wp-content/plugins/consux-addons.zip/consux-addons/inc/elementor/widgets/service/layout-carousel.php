<div class="consux-service list-carousel" data-autoplay="<?php echo esc_attr( empty( $settings['carousel_autoplay'] ) ? 'false' : 'true' ); ?>" data-loop="<?php echo esc_attr( empty( $settings['carousel_infinite'] ) ? 'false' : 'true' ); ?>" data-hide-navigation="<?php echo esc_attr( empty( $settings['hide_navigation'] ) ? 'true' : 'false' ); ?>">
<?php
$per_page = $settings['number'] ? $settings['number'] : -1;
$args = array(
	'post_type'	=>	'service',
	'post_status'	=>	'publish',
	'orderby'	=>	$settings['orderby'],
	'order'	=>	$settings['order'],
	'posts_per_page'	=>	$per_page
);
$query = new WP_Query( $args );
$current_id = -1;
if ( is_singular( 'service' ) )
{
	$current_id = get_the_ID();
}
if	( $query->have_posts() ):
?>
	<div class="services">
	<?php
	while( $query->have_posts() ): $query->the_post();
	?>
		<article <?php post_class( 'col' ); ?>>
			<div class="outer">
				<?php
				$icon = consux_get_post_meta( 'mb_icon' );
				if ( $icon )
				{
				?>
					<div class="service-icon"><i class="<?php echo esc_attr( $icon ); ?>"></i></div>
				<?php
				}
				?>
				<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<div class="excerpt">
				<?php
				echo get_the_excerpt();
				?>
				</div>
			</div>
		</article>
	<?php
	endwhile;
	wp_reset_postdata();
	?>	
	</div>
<?php
endif
?>
</div>