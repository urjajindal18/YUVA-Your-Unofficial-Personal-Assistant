<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

class Cosnux_Service_Widget extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'consux_service';
	}

	public function get_title()
	{
		return esc_html__('Services', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-settings';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{
		$this->tab_content();
		$this->tab_style();
	}

	private function tab_content ()
	{
		$this->start_controls_section(
			'section_title',
			[
				'label' => esc_html__( 'Service', 'consux' ),
			]
		);

		$this->add_control(
			'layout',
			[
				'label'	=>	esc_html__( 'Layout', 'consux' ),
				'type'	=>	Controls_Manager::SELECT,
				'default'   =>  'layout-list',
				'options' => [
					'layout-list' => __('List', 'consux'),
					'layout-grid' => __('Grid', 'consux'),
					'layout-carousel' => __('Carousel', 'consux'),
				],
			]
		);

		$this->add_control(
			'number',
			[
				'label'	=>	esc_html__( 'Number of service showed', 'consux' ),
				'type'	=>	Controls_Manager::TEXT
			]
		);

		$this->add_control(
			'grid_enable_carousel',
			[
				'label'	=> esc_html__( 'Enable Carousel','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  [ 'layout-grid' ]
				]
			]
		);

		$this->add_control(
			'grid_carousel_autoplay',
			[
				'label'	=> esc_html__( 'Autoplay','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'grid_enable_carousel'    =>  'yes'
				]
			]
		);

		$this->add_control(
			'grid_hide_pagination',
			[
				'label'	=> esc_html__( 'Hide Pagination','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'grid_enable_carousel'    =>  'yes'
				]
			]
		);

		$this->add_control(
			'grid_carousel_infinite',
			[
				'label'	=> esc_html__( 'Enable Loop','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'grid_enable_carousel'    =>  'yes'
				]
			]
		);

		$this->add_control(
			'carousel_autoplay',
			[
				'label'	=> esc_html__( 'Autoplay','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  [ 'layout-carousel' ]
				]
			]
		);

		$this->add_control(
			'hide_navigation',
			[
				'label'	=> esc_html__( 'Hide Navigation','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  [ 'layout-carousel' ]
				]
			]
		);

		$this->add_control(
			'carousel_infinite',
			[
				'label'	=> esc_html__( 'Loop Infinite','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  [ 'layout-carousel' ]
				]
			]
		);

		$this->add_control(
			'show_all_services',
			[
				'label' => esc_html__( 'Show All Services Link', 'consux' ),
				'type'  => Controls_Manager::SWITCHER,
				'label_on'  =>  esc_html__( 'Show', 'consux' ),
				'label_off'  =>  esc_html__( 'Hide', 'consux' ),
				'return_value'  =>  'yes',
				'default'   =>  '',
				'condition' =>  [
					'layout'    =>  'layout-list'
				]
			]
		);

		$this->add_control(
			'all_services_text',
			[
				'label'	=>	esc_html__( 'All service text', 'consux' ),
				'type'	=>	Controls_Manager::TEXT,
				'condition' =>  [
					'show_all_services' =>  'yes'
				]
			]
		);

		$this->add_control(
			'all_services_url',
			[
				'label'	=>	esc_html__( 'All service url', 'consux' ),
				'type'	=>	Controls_Manager::TEXT,
				'condition' =>  [
					'show_all_services' =>  'yes'
				]
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'service_query',
			[
				'label' =>  esc_html__( 'Query', 'consux' ),
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' => __( 'Order By', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'post_date',
				'options' => [
					'post_date' => __( 'Date', 'consux' ),
					'post_title' => __( 'Title', 'consux' ),
					'menu_order' => __( 'Menu Order', 'consux' ),
					'rand' => __( 'Random', 'consux' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label' => __( 'Order', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc' => __( 'ASC', 'consux' ),
					'desc' => __( 'DESC', 'consux' ),
				],
			]
		);

		$this->end_controls_section();

	}

	private function tab_style ()
	{
		// Service Carousel
		$this->start_controls_section(
			'section_serivce_carousel_style',
			[
				'label' => __( 'Service', 'consux' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' =>  [
					'layout'    =>  'layout-carousel'
				]
			]
		);
		$this->start_controls_tabs( 'service_carousel_style_tabs' );

		$this->start_controls_tab(
			'sc_tab_normal',
			[
				'label'	=> esc_html__( 'Normal', 'consux' ),
			]
		);
		$this->add_control(
			'sc_container_background_color',
			[
				'label' => __( 'Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer' => 'background-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'sc_container_border_color',
			[
				'label' => __( 'Border Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#434343',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer' => 'border-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'sc_icon_color',
			[
				'label' => __( 'Icon Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer i' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'sc_title_color',
			[
				'label' => __( 'Title Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer h3 a' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'sc_excerpt_color',
			[
				'label' => __( 'Excerpt Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer .excerpt' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'sc_tab_hover',
			[
				'label'	=> esc_html__( 'Hover', 'consux' ),
			]
		);
		$this->add_control(
			'sc_container_background_color_hover',
			[
				'label' => __( 'Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer:hover' => 'background-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'sc_container_border_color_hover',
			[
				'label' => __( 'Border Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer:hover' => 'border-color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'sc_icon_color_hover',
			[
				'label' => __( 'Icon Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer:hover i' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'sc_title_color_hover',
			[
				'label' => __( 'Title Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer:hover h3 a' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'sc_excerpt_color:hover',
			[
				'label' => __( 'Excerpt Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-carousel .services article .outer:hover .excerpt' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		// Service list
		$this->start_controls_section(
			'section_serivce_style',
			[
				'label' => __( 'Service', 'consux' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' =>  [
					'layout'    =>  'layout-list'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'service_typography',
				'selector' => '{{WRAPPER}} .consux-service.list-layout ul li a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);

		$this->start_controls_tabs( 'service_style_tabs' );

		$this->start_controls_tab(
			'normal',
			[
				'label'	=> esc_html__( 'Normal', 'consux' ),
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => __( 'Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#eee',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-layout ul li a' => 'background-color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'border_color',
			[
				'label' => __( 'Border Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#d0d0d0',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-layout ul li a:before' => 'background-color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => __( 'Text Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#222',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-layout ul li a' => 'color: {{VALUE}};',
				],
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
			]
		);

		$this->end_controls_tab(); // end tab normal
		$this->start_controls_tab(
			'hover',
			[
				'label'	=> esc_html__( 'Hover', 'consux' ),
			]
		);

		$this->add_control(
			'background_color_hover',
			[
				'label' => __( 'Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#eee',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-layout ul li a:hover:after' => 'background-color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'border_color_hover',
			[
				'label' => __( 'Border Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#d0d0d0',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-layout ul li a:hover:before' => 'background-color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'text_color_hover',
			[
				'label' => __( 'Text Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#222',
				'selectors' => [
					'{{WRAPPER}} .consux-service.list-layout ul li a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-service.list-layout ul li a.current-post' => 'color: {{VALUE}};',
				],
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
			]
		);

		$this->end_controls_tab(); // end tab hover
		$this->end_controls_tabs(); // end service_style_tabs
		$this->end_controls_section();

		// Service grid

		$this->start_controls_section( 
			'service_grid_panel_style',
			[
				'label'	=>	esc_html__( 'Service', 'consux' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' =>  [
					'layout'    =>  'layout-grid'
				]
			]
		);

		$this->add_control(
			'service_grid_title_color',
			[
				'label' => __( 'Title Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#222',
				'selectors' => [
					'{{WRAPPER}} .consux-service.grid-layout .service .inner-wrapper .info h3 a' => 'color: {{VALUE}};'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'service_grid_title_typography',
				'selector' => '{{WRAPPER}} .consux-service.grid-layout .service .inner-wrapper .info h3',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);

		$this->add_control(
			'service_grid_excerpt_color',
			[
				'label' => __( 'Excerpt Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#777',
				'separator'   => 'before',
				'selectors' => [
					'{{WRAPPER}} .consux-service.grid-layout .service .inner-wrapper .info .content' => 'color: {{VALUE}};'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'service_grid_excerpt_typography',
				'selector' => '{{WRAPPER}} .consux-service.grid-layout .service .inner-wrapper .info .content',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);

		$this->add_control(
			'service_grid_link_color',
			[
				'label' => __( 'Link Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#222',
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .consux-service.grid-layout .service a.has-icon' => 'color: {{VALUE}};'
				],
			]
		);
		$this->add_control(
			'service_grid_link_hover_color',
			[
				'label' => __( 'Link Hover Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#222',
				'selectors' => [
					'{{WRAPPER}} .consux-service.grid-layout .service a.has-icon:hover' => 'color: {{VALUE}};'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'service_grid_link_typography',
				'selector' => '{{WRAPPER}} .consux-service.grid-layout .service a.has-icon',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);

		$this->end_controls_section(); // end grid section

	}
	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) . '/' . $settings['layout'] .'.php';
	}
}

$widgets_manager->register_widget_type(new \Cosnux_Service_Widget());