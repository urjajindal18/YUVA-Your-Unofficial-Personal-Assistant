<?php
$enable_carousel = $settings['grid_enable_carousel'] ? 'enable-carousel carousel-dot-style-circle' : '';
?>
<div class="consux-service grid-layout container <?php echo esc_attr( $enable_carousel ); ?>" data-autoplay="<?php echo esc_attr( empty( $settings['grid_carousel_autoplay'] ) ? 'false' : 'true' ); ?>" data-loop="<?php echo esc_attr( empty( $settings['grid_carousel_infinite'] ) ? 'false' : 'true' ); ?>" data-hide-pagination="<?php echo esc_attr( empty( $settings['grid_hide_pagination'] ) ? 'true' : 'false' ); ?>">
<?php
$per_page = $settings['number'] ? $settings['number'] : -1;
$args = array(
	'post_type'	=>	'service',
	'post_status'	=>	'publish',
	'orderby'	=>	$settings['orderby'],
	'order'	=>	$settings['order'],
	'posts_per_page'	=>	$per_page
);
$query = new WP_Query( $args );
$current_id = -1;
if ( is_singular( 'service' ) )
{
	$current_id = get_the_ID();
}
if	( $query->have_posts() ):

	?>
	<div class="services row">
	<?php
	while( $query->have_posts() ): $query->the_post();
	?>
	<div <?php post_class( 'col-12 col-sm-6 col-lg-4 service' ); ?>>
		<div class="inner-wrapper">
			<?php
			if ( has_post_thumbnail() )
			{
				?>
				<div class="thumbnail">
					<figure class="hover-zoomin">
					<?php
					tz_get_image_custom_size_html( get_post_thumbnail_id(), 370, 270 );
					?>
					</figure>
				</div>
				<?php
			}
			?>
			<div class="info">
				<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<div class="content">
					<?php echo wp_trim_words( get_the_excerpt(), 16, '...' ); ?>
				</div>
				<a href="<?php the_permalink(); ?>" class="button has-icon"><?php echo esc_html__( 'Read more', 'consux' ); ?><i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
			</div>
		</div>

	</div>
	<?php
	endwhile;
	wp_reset_postdata();
	?>
	</div> <!-- end .services-->
	<?php
endif
?>
</div>