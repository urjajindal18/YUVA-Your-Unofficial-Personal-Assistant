<div class="consux-service list-layout">
<?php
$per_page = $settings['number'] ? $settings['number'] : -1;
$args = array(
	'post_type'	=>	'service',
	'post_status'	=>	'publish',
	'orderby'	=>	$settings['orderby'],
	'order'	=>	$settings['order'],
	'posts_per_page'	=>	$per_page
);
$query = new WP_Query( $args );
$current_id = -1;
if ( is_singular( 'service' ) )
{
	$current_id = get_the_ID();
}
if	( $query->have_posts() ):
?>
	<ul>
	<?php
	if ( $settings['show_all_services'] )
	{
		?>
		<li><a href="<?php echo esc_url( $settings['all_services_url'] ); ?>"><?php echo esc_html( $settings['all_services_text'] ); ?></a></li>
		<?php
	}
	while( $query->have_posts() ): $query->the_post();
		$post_class = '';
		if ( $current_id == get_the_ID() )
		{
			$post_class = 'current-post';
		}
	?>
		<li><a class="<?php echo esc_attr( $post_class ); ?>" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
	<?php
	endwhile;
	wp_reset_postdata();
	?>	
	</ul>
<?php
endif
?>
</div>