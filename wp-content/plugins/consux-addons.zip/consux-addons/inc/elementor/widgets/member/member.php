 <?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class Consux_Member_Widget extends Widget_Base {

	public function get_name()
	{
		return 'consux_member';
	}

	public function get_title()
	{
		return esc_html__('Member', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-person';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		// Content Tab
		$this->tab_content();
		// Tab Style
		$this->tab_style();
	}

	// section and element on tab content
	private function tab_content ()
	{
		$this->start_controls_section(
			'member_step_info',
			[
				'label' => __('Member', 'consux'),
			]
		);
		$this->add_control(
			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'label_block' => true,
				'default'   =>  'layout-carousel',
				'options' => [
					'layout-carousel' => __('Carousel', 'consux'),
					'layout-grid' => __('Grid', 'consux'),
				],
			]
		);
		$this->add_control(
			'per_page',
			[
				'label' => esc_html__( 'Number Member Show', 'consux' ),
				'type'  => Controls_Manager::NUMBER,
				'min'   => -1,
				'step'  => 1,
				'default'   => 12
			]
		);

		$this->add_control(
			'carousel_autoplay',
			[
				'label'	=> esc_html__( 'Autoplay','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  'layout-carousel'
				]
			]
		);
		$this->add_control(
			'hide_pagination',
			[
				'label'	=> esc_html__( 'Hide Pagination', 'consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  'layout-carousel'
				]
			]
		);
		$this->end_controls_section(); // End section Info

		$this->start_controls_section(
			'case_study_query',
			[
				'label' =>  esc_html__( 'Query', 'consux' ),
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' => __( 'Order By', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'post_date',
				'options' => [
					'post_date' => __( 'Date', 'consux' ),
					'post_title' => __( 'Title', 'consux' ),
					'menu_order' => __( 'Menu Order', 'consux' ),
					'rand' => __( 'Random', 'consux' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label' => __( 'Order', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc' => __( 'ASC', 'consux' ),
					'desc' => __( 'DESC', 'consux' ),
				],
			]
		);

		$this->end_controls_section();
	}

	// section and element on tab style
	private function tab_style()
	{
		$this->start_controls_section(
			'section_style',
			[
				'label' =>  esc_html__( 'Content', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_color',
			[
				'label' => __( 'Name Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#222',
				'selectors' => [
					'{{WRAPPER}} .member-container.layout-carousel .member .information .entry-title a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .member-container.layout-grid .member .information .entry-title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'name_color_hover',
			[
				'label' => __( 'Name Color Hover', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#222',
				'selectors' => [
					'{{WRAPPER}} .member-container.layout-carousel .member .information .entry-title a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .member-container.layout-grid .member .information .entry-title a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography' ),
				'name'  =>  'name_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .member-container .member .information .entry-title',
			]
		);

		$this->add_responsive_control(
			'name_spacing',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .member-container.layout-carousel .member .entry-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .member-container.layout-grid .member .entry-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Job Style

		$this->add_control(
			'job_color',
			[
				'label' => __( 'Job Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'separator' =>  'before',
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .member-container.layout-carousel .member .information .job' => 'color: {{VALUE}};',
					'{{WRAPPER}} .member-container.layout-grid .member .information .job' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography' ),
				'name'  =>  'job_typo',
				'scheme'    =>  Scheme_Typography::TYPOGRAPHY_1,
				'selector' =>  '{{WRAPPER}} .member-container .member .information .job',
			]
		);

		$this->add_responsive_control(
			'job_spacing',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .member-container.layout-carousel .member .job' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .member-container.layout-grid .member .job' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Social Icons
		$this->add_control(
			'social_color',
			[
				'label' => __( 'Social Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'separator' =>  'before',

				'default' => '#999',
				'selectors' => [
					'{{WRAPPER}} .member-container.layout-carousel .member .information .socials a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .member-container.layout-grid .member .information .socials a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'social_color_hover',
			[
				'label' => __( 'Social Color Hover', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .member-container.layout-carousel .member .information .socials a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .member-container.layout-grid .member .information .socials a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => esc_html__( ' Size', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 17,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .member-container.layout-carousel .member .information .socials a' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .member-container.layout-grid .member .information .socials a' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_space',
			[
				'label' => esc_html__( ' Space', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .member-container.layout-carousel .member .information .socials a + a' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .member-container.layout-grid .member .information .socials a + a' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) . '/' . $settings['layout'] .'.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_Member_Widget());