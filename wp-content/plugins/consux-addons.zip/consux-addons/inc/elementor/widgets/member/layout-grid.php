<?php
$members = consux_get_members( $settings );
?>
<div class="member-container layout-grid">
<?php
if ( $members )
{
	echo '<div class="members d-flex">';
	while ($members->have_posts()) : $members->the_post();
		$col = 'member';
	?>
		<article <?php post_class( $col ); ?>>
			<div class="outer">
			<?php
			if ( has_post_thumbnail() )
			{
			?>
			<div class="thumbnail">
				<?php
				$image_id = get_post_thumbnail_id();
				$image = tz_get_image_custom_size_html( $image_id, 480, 431 );
				if ( $image )
				{
					echo $image;
				}
				?>
			</div>
			<?php
			}
			?>
				<div class="information">
					<div class="inner">
						<h3 class="entry-title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
						<div class="job"><?php echo consux_get_post_meta( 'member_job' ); ?></div>
						<div class="socials">
							<?php
							$socials = array( 'facebook', 'google_plus', 'twitter', 'pinterest', 'skype' );
							foreach( $socials as $social )
							{
								$url = consux_get_post_meta( $social );
								$icon = $social == 'google_plus' ? 'google-plus' : $social;
								?>
								<a target="_blank" href="<?php echo esc_url( $url ); ?>"><i class="fa fa-<?php echo esc_attr( $icon ); ?>"></i></a>
								<?php
							}
							?>
						</div>
					</div>
				</div>
			</div>
		</article>
	<?php
	endwhile;
	wp_reset_postdata();
	echo '</div>';
}
?>
</div>