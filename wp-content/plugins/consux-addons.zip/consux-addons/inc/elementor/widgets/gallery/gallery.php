<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class Consux_Gallery extends Widget_Base {

	public function get_name()
	{
		return 'consux_gallery';
	}

	public function get_title()
	{
		return esc_html__('Gallery', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-gallery-masonry';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() 
	{
		$this->tab_content();
		$this->tab_style();

	}
	// section and element on tab style
	private function tab_style()
	{
		$this->start_controls_section(
			'section_style',
			[
				'label' =>  esc_html__( 'Images', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 25,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-gallery-container .grid .grid-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'consux' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .consux-gallery-container .grid .grid-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	private function tab_content()
	{
		$this->start_controls_section(
			'section_gallery',
			[
				'label' => __('Gallery', 'consux'),
			]
		);

		$this->add_control(
			'images',
			[
				'label' => __( 'Add Images', 'consux' ),
				'type' => Controls_Manager::GALLERY,
				'show_label' => false,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) .'/layout-masonry.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_Gallery());