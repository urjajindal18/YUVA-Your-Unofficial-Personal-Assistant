<?php
if  ( count( $settings['images'] ) < 1 ) {
    return;
}
?>
<div class="consux-gallery-container clreafix">
    <div class="grid row">
        <?php
        foreach( $settings['images'] as $img ) 
        {
            $random = random_int( 0, 1 );
            $img_full = wp_get_attachment_image_src( $img['id'], 'full' )
            ?>
            <div class="grid-item col-md-4">
                <div class="item">
                    <span data-link="<?php echo esc_url( $img_full[0] ); ?>" class="photoswipe" data-width="<?php echo esc_attr( $img_full[1] ); ?>" data-height="<?php echo esc_attr( $img_full[2] ); ?>">
                    <?php
                        if( $random ) 
                        {
                            echo tz_get_image_custom_size_html( $img['id'], 370, 572 );
                        }
                        else
                        {
                            echo tz_get_image_custom_size_html( $img['id'], 370, 271 );
                        }
                    ?>
                        <span class="icon">

                    </span>
                    </span>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
</div>