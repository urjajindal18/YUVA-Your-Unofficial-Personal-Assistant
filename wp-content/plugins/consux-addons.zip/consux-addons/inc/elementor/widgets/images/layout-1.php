<?php
use Elementor\Group_Control_Image_Size;
use Elementor\Control_Media;
use Elementor\Plugin;

if ( empty( $settings['images'] ) ) {
	return;
}

$slides = [];
foreach ( $settings['images'] as $image )
{
	$image_url = Group_Control_Image_Size::get_attachment_image_src( $image['carousel_image']['id'], 'image_size', $settings );
	$image_html = '<div class="col"><div class="outer"><a href="' . esc_url( $image['carousel_url'] ) . '"><img src="' . esc_attr( $image_url ) . '" alt="' . esc_attr( Control_Media::get_image_alt( $image ) ) . '" /></a></div></div>';
	$slides[] = $image_html;
}

?>
<div class="consux-images layout-1 carousel-dot-style-circle" data-columns="<?php echo esc_attr( $settings['columns'] ); ?>" data-autoplay="<?php echo esc_attr( empty( $settings['carousel_autoplay'] ) ? 'false' : 'true' ); ?>" data-hide-pagination="<?php echo esc_attr( empty( $settings['hide_pagination'] ) ? 'true' : 'false' ); ?>">
	<div class="images">
		<?php echo implode( '', $slides ); ?>
	</div>
</div>