<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Color;

class Consux_Image_Widget extends Widget_Base {

	public function get_name()
	{
		return 'consux_images';
	}

	public function get_title()
	{
		return esc_html__('Images', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-image';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		// Content Tab
		$this->tab_content();
		// Tab Style
		$this->tab_style();
	}

	// section and element on tab content
	private function tab_content ()
	{
		$this->start_controls_section(
			'case_study_step_info',
			[
				'label' => __('Images', 'consux'),
			]
		);
		$this->add_control(
			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'label_block' => true,
				'default'   =>  'layout-1',
				'options' => [
					'layout-1' => __('Carousel', 'consux'),
				],
			]
		);
		$repeater = new Elementor\Repeater();
		$repeater->add_control(
			'carousel_image',
			[
				'label' => __( 'Choose Image', 'consux' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'carousel_url',
			[
				'label' => __( 'URL', 'consux' ),
				'type' => Controls_Manager::TEXT,
				'default'   =>  '#'
			]
		);
		$this->add_control(
			'images',
			[
				'label' => __( 'Add Images', 'consux' ),
				'type' => Controls_Manager::REPEATER,
				'fields'    =>  $repeater->get_controls(),
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->add_control(
			'columns',
			[
				'label' => esc_html__( 'Columns', 'consux' ),
				'type'  =>  Controls_Manager::SELECT,
				'default'   =>  '6',
				'options' => [
					'1' => esc_html__('1', 'consux'),
					'2' => esc_html__('2', 'consux'),
					'3' => esc_html__('3', 'consux'),
					'4' => esc_html__('4', 'consux'),
					'5' => esc_html__('5', 'consux'),
					'6' => esc_html__('6', 'consux'),
				],
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name' => 'image_size', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
				'default' => 'thumbnail',
				'separator' => 'none',
			]
		);

		$this->add_control(
			'carousel_autoplay',
			[
				'label'	=> esc_html__( 'Autoplay','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);
		$this->add_control(
			'hide_pagination',
			[
				'label'	=> esc_html__( 'Hide Pagination', 'consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->end_controls_section();
	}

	// section and element on tab style
	private function tab_style()
	{
		$this->start_controls_section(
			'section_style',
			[
				'label' =>  esc_html__( 'Images', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'image_effects');

		$this->start_controls_tab( 'normal',
			[
				'label' => __( 'Normal', 'consux' ),
			]
		);

		$this->add_control(
			'opacity',
			[
				'label' => __( 'Opacity', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'min' => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-images.layout-1 img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters_1',
				'selector' => '{{WRAPPER}} .consux-images.layout-1 img',
				'condition'	=> [
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'image_2_border_1',
				'selector' => '{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer',
				'condition'	=> [
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_box_shadow_1',
				'exclude' => [
					'box_shadow_position',
				],
				'selector' => '{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer',
				'condition'	=> [
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'hover',
			[
				'label' => __( 'Hover', 'consux' ),
			]
		);

		$this->add_control(
			'opacity_hover',
			[
				'label' => __( 'Opacity', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'min' => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer:hover img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters_hover_1',
				'selector' => '{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer:hover img',
				'condition'	=>	[
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_box_1_shadow_hover',
				'exclude' => [
					'box_shadow_position',
				],
				'selector' => '{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer:hover',
				'condition'	=>	[
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'image_1_hover_border',
				'selector' => '{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer:hover',
				'condition'	=>	[
					'layout'	=>	'layout-1'
				]
			]
		);

		$this->add_control(
			'image_hover_transition',
			[
				'label' => __( 'Transition Duration', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer' => 'transition-duration: {{SIZE}}s',
					'{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer img' => 'transition-duration: {{SIZE}}s',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'image_border_radius',
			[
				'label' => __( 'Border Radius', 'consux' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);
		$this->add_responsive_control(
			'image_container_padding',
			[
				'label' => __( 'Padding', 'butler' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .consux-images.layout-1 .slick-list .slick-slide .outer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) . '/' . $settings['layout'] .'.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_Image_Widget());