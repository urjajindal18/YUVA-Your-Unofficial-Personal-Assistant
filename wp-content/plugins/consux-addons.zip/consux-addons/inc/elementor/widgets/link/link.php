<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class CONSUX_Link extends Widget_Base {

	public function get_name()
	{
		return 'consux_link';
	}

	public function get_title()
	{
		return esc_html__('Link', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-editor-link';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_icon_box',
			[
				'label' => __('Link', 'consux'),
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => esc_html__( 'Icon', 'consux' ),
				'type'  => Controls_Manager::ICON,
				'default' => 'fa fa-angle-double-right',
			]
		);

		$this->add_control(
			'title_text',
			[
				'label' =>  esc_html__( 'Text', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'Read more', 'consux' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'url',
			[
				'label' =>  esc_html__( 'Url', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( '#', 'consux' ),
				'label_block' => true,
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => __( 'Align', 'consux' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'text-left',
				'options' => [
					'left' => [
						'title' => __( 'Left', 'consux' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'consux' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'consux' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-widget-container' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();

		// Tab Panel
		// Icon section
		$this->start_controls_section(
			'link_section_style',
			[
				'label' =>  esc_html__( 'Link', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'primary_color',
			[
				'label' => __( 'Primary Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .consux-link-container .link' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'primary_color_hover',
			[
				'label' => esc_html__( 'Primary Color Hover', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .consux-link-container .link:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'link_typography',
				'selector' => '{{WRAPPER}} .consux-link-container .link',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);

		$this->add_responsive_control(
			'icon_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 10,
				],
				'range' => [
					'px' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-link-container .link i' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();		// End Icon section

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) .'/layout-1.php';
	}

}
$widgets_manager->register_widget_type(new \CONSUX_Link());