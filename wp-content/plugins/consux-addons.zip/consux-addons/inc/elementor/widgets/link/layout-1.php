<?php
$link = isset( $settings['url'] ) ? $settings['url'] : '#';
$text = isset( $settings['title_text'] ) ? $settings['title_text'] : '';
$icon = isset( $settings['icon'] ) ? $settings['icon'] : '';
$align = isset( $settings['align'] ) ? $settings['align'] : '';
?>
<div class="consux-link-container">
	<a class="link" href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $text ); ?><i class="<?php echo esc_attr( $icon ); ?>"></i></a>
</div>