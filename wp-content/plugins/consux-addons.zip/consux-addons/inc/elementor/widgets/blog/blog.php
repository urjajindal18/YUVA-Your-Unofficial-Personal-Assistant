<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class Consux_Blog_Widget extends Widget_Base {

	public function get_name()
	{
		return 'consux_blog';
	}

	public function get_title()
	{
		return esc_html__('Blog', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-posts-grid';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		// Content Tab
		$this->tab_content();
		// Tab Style
		$this->tab_style();
	}

	// section and element on tab content
	private function tab_content ()
	{
		$this->start_controls_section(
			'case_study_step_info',
			[
				'label' => __('Blog', 'consux'),
			]
		);
		$this->add_control(
			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'label_block' => true,
				'default'   =>  'layout-grid',
				'options' => [
					'layout-grid' => __('Layout Grid', 'consux'),
					'layout-list' => __('Layout List', 'consux'),
				],
			]
		);
		$this->add_control(
			'per_page',
			[
				'label' => esc_html__( 'Number Post Show', 'consux' ),
				'type'  => Controls_Manager::NUMBER,
				'min'   => -1,
				'step'  => 1,
				'default'   => 12
			]
		);
		$this->add_control(
			'hide_category',
			[
				'label'	=> esc_html__( 'Hide Post Category','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'consux' ),
				'label_off' => esc_html__( 'Hide', 'consux' ),
				'return_value'	=>	'none',
				'default'	=>	'',
				'selectors' =>  [
					'{{WRAPPER}} .post.layout-grid_no_sidebar .entry-header .thumbnail .categories' => 'display: {{VALUE}};',
				]
			]
		);

		$this->end_controls_section(); // End section Info

		$this->start_controls_section(
			'blog_query',
			[
				'label' =>  esc_html__( 'Query', 'consux' ),
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' => __( 'Order By', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'post_date',
				'options' => [
					'post_date' => __( 'Date', 'consux' ),
					'post_title' => __( 'Title', 'consux' ),
					'menu_order' => __( 'Menu Order', 'consux' ),
					'rand' => __( 'Random', 'consux' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label' => __( 'Order', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'desc',
				'options' => [
					'asc' => __( 'ASC', 'consux' ),
					'desc' => __( 'DESC', 'consux' ),
				],
			]
		);

		$this->add_control(
			'category',
			[
				'label' => __( 'Category', 'consux' ),
				'type' => Controls_Manager::SELECT2,
				'label_block' => true,
				'default' => [],
				'options' => consux_get_post_categories(),
			]
		);

		$this->end_controls_section();
	}

	// section and element on tab style
	private function tab_style()
	{

		$this->start_controls_section(
			'section_style',
			[
				'label' =>  esc_html__( 'Blog Content', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'meta_bg_color',
			[
				'label' => __( 'Meta Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .blog-list-container.layout-grid article .post_meta' => 'background-color: {{VALUE}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-grid'
				]
			]
		);

		$this->add_control(
			'meta_color',
			[
				'label' => __( 'Meta Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'separator' =>  'after',
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .blog-list-container.layout-grid article .post_meta > div' => 'color: {{VALUE}};',
					'{{WRAPPER}} .blog-list-container.layout-grid article .post_meta .categories a' => 'color: {{VALUE}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-grid'
				]
			]
		);

		$this->add_control(
			'title_primary_color',
			[
				'label' => __( 'Title Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#222',
				'selectors' => [
					'{{WRAPPER}} .blog-list-container.layout-grid article .entry-content h3 a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .blog-list-container.layout-list article .outer .entry-content h3 a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_primary_hover_color',
			[
				'label' => __( 'Title Hover Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .blog-list-container.layout-grid article .entry-content h3 a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .blog-list-container.layout-list article .outer .entry-content h3 a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_space_down',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 6,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'separator' =>  'after',
				'selectors' => [
					'{{WRAPPER}} .blog-list-container.layout-grid article .entry-content h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .blog-list-container.layout-list article .outer .entry-content h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'excerpt_primary_color',
			[
				'label' => esc_html__( 'Excerpt Color' ),
				'type'  => Controls_Manager::COLOR,
				'scheme'    =>  [
					'type'  => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1
				],
				'default'   =>  '#777',
				'selectors' =>  [
					'{{WRAPPER}} .blog-list-container.layout-grid article .entry-content .content' => 'color: {{VALUE}};',
					'{{WRAPPER}} .blog-list-container.layout-list article .outer .entry-content .excerpt' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'excerpt_space_down',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 18,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .blog-list-container.layout-grid article .entry-content .content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .blog-list-container.layout-list article .outer .entry-content .excerpt' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				]
			]
		);

		$this->add_control(
			'link_color',
			[
				'label' => esc_html__( 'Link Color' ),
				'type'  => Controls_Manager::COLOR,
				'scheme'    =>  [
					'type'  => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1
				],
				'default'   =>  '#7eb729',
				'separator' => 'before',
				'selectors' =>  [
					'{{WRAPPER}} .blog-list-container.layout-grid article .read-more a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .blog-list-container.layout-list article .outer .entry-content .read-more a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'link_color_hover',
			[
				'label' => esc_html__( 'Link Color Hover' ),
				'type'  => Controls_Manager::COLOR,
				'scheme'    =>  [
					'type'  => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1
				],
				'default'   =>  '#7eb729',
				'selectors' =>  [
					'{{WRAPPER}} .blog-list-container.layout-grid article .read-more a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .blog-list-container.layout-list article .outer .entry-content .read-more a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) . '/' . $settings['layout'] .'.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_Blog_Widget());