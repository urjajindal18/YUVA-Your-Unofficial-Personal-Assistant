<?php
$args = array(
	'post_status'           => 'publish',
	'ignore_sticky_posts'   => 1,
	'posts_per_page'        => $settings['per_page']
);

if ( isset( $settings['category'] ) && $settings['category'] )
{
	$args['tax_query'] =  array(
		array(
			'taxonomy' => 'categories',
			'terms'    => $settings['category'],
			'field'    => 'slug',
		)
	);
}

$args['orderby'] = $settings['orderby'];
$args['order']   = $settings['order'];

$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
$args['paged'] = $paged;

$posts = new WP_Query( $args );
?>
<div class="blog-list-container layout-list">

	<div class="list-posts">
		<?php
		if ( $posts->have_posts() )
		{
			while ($posts->have_posts()) : $posts->the_post();
			?>
				<article <?php post_class(); ?>>
					<div class="outer d-flex">
						<?php
						if ( has_post_thumbnail() )
						{
							?>
							<div class="thumbnail hover-zoomin">
								<a href="<?php the_permalink(); ?>">
									<?php
									$image_id = get_post_thumbnail_id();
									$image = tz_get_image_custom_size_html( $image_id, 96, 96 );
									if ( $image )
									{
										echo $image;
									}
									?>
								</a>
							</div>
							<?php
						}
						?>
						<div class="entry-content">
							<h3 class="entry-title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
							<div class="excerpt">
							<?php echo wp_trim_words( get_the_excerpt(), 13, '...' );; ?>
							</div>
							<div class="read-more">
								<a href="<?php the_permalink(); ?>" class="button"><?php echo esc_html__( 'Read more', 'consux' ); ?><i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
							</div><!-- .entry-footer -->
						</div>
					</div>
				</article>
			<?php
			endwhile;
			wp_reset_postdata();
		}
		?>
	</div>
</div>