<?php
$id = uniqid( 'timer-' );
?>
<div id="<?php echo esc_attr( $id );?>" class="consux-countdown-container layout-1 container" data-date="<?php echo date( 'F d, Y', strtotime( $settings['coming_date'] ) ); ?>">
	<div class="row justify-content-between">
		<div class="col-md-3 col-6">
			<div class="timer__section days">
				<div class="timer_text">
					<div class="timer__number">364</div>
					<div class="timer__label">days</div>
				</div>
			</div>
		</div>
		<div class="col-md-3 col-6">
			<div class="timer__section hours">
				<div class="timer_text">
					<div class="timer__number">23</div>
					<div class="timer__label">hours</div>
				</div>
			</div>
		</div>
		<div class="col-md-3 col-6">
			<div class="timer__section minutes">
				<div class="timer_text">
					<div class="timer__number">41</div>
					<div class="timer__label">Minutes</div>
				</div>
			</div>
		</div>
		<div class="col-md-3 col-6">
			<div class="timer__section seconds">
				<div class="timer_text">
					<div class="timer__number">19</div>
					<div class="timer__label">seconds</div>
				</div>
			</div>
		</div>
	</div>
</div>