<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class Consux_CountDown extends Widget_Base {

	public function get_name()
	{
		return 'consux_countdown';
	}

	public function get_title()
	{
		return esc_html__('Countdown', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-countdown';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_icon_box',
			[
				'label' => __('Time', 'consux'),
			]
		);

		$this->add_control(
			'coming_date',
			[
				'label' =>  esc_html__( 'Coming Date', 'consux' ),
				'type'  => Controls_Manager::DATE_TIME,
				'picker_options' => [
					'dateFormat' => 'm/d/Y',
				],
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		// Tab Panel
		// Icon section
		$this->start_controls_section(
			'link_section_style',
			[
				'label' =>  esc_html__( 'Time', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'primary_color',
			[
				'label' => __( 'Primary Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}  .consux-countdown-container .timer__number' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'time_typography',
				'selector' => '{{WRAPPER}}  .consux-countdown-container .timer__number',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);

		$this->add_responsive_control(
			'icon_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 10,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-countdown-container .timer__number' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'label_color',
			[
				'label' => __( 'label Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'separator' =>  'before',
				'selectors' => [
					'{{WRAPPER}} .consux-countdown-container .timer__label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'label_typography',
				'selector' => '{{WRAPPER}} .consux-countdown-container .timer__label',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);


		$this->end_controls_section();		// End Icon section

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) .'/layout-1.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_CountDown());