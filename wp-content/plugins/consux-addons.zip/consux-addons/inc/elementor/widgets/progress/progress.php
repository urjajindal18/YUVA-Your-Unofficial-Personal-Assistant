<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class CONSUX_Progress extends Widget_Base {

	public function get_name()
	{
		return 'consux_progress';
	}

	public function get_title()
	{
		return esc_html__('Progress', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-skill-bar';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_icon_box',
			[
				'label' => __('Progress', 'consux'),
			]
		);

		$this->add_control(
			'skill',
			[
				'label' =>  esc_html__( 'Skill', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'percent',
			[
				'label' => __( 'Percentage', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' =>  [
					'min'   =>  0,
					'max'   =>  100
				],
				'default' => [
					'size' => 50,
					'unit' => '%',
				],
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		// Tab Panel
		// Icon section
		$this->start_controls_section(
			'progress_section_style',
			[
				'label' =>  esc_html__( 'Progress', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'progress_color',
			[
				'label' => __( 'Progress Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-progress-container .progress .progress-bar' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'progress_container_color',
			[
				'label' => __( 'Progress Container Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#c8c8c8',
				'selectors' => [
					'{{WRAPPER}} .consux-progress-container .progress' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();		// End Icon section

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) .'/layout-1.php';
	}

}
$widgets_manager->register_widget_type(new \CONSUX_Progress());