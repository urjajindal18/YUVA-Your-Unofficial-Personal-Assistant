<div class="consux-progress-container">
	<div class="progress-title">
		<div><?php echo $settings['skill'] ? $settings['skill'] : ''; ?></div>
		<div><?php echo $settings['percent']['size'] . $settings['percent']['unit'] ?></div>
	</div>
	<div class="progress">
		<div class="progress-bar" role="progressbar" aria-valuenow="<?php echo esc_attr( $settings['percent']['size'] ); ?>" aria-valuemin="0" aria-valuemax="100"></div>
	</div>
</div>
