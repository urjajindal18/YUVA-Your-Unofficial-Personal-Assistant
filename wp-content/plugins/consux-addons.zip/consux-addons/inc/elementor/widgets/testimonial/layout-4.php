<?php

$link = isset( $settings['link'] ) ? $settings['link'] : '#';
?>
<div class="consux-testimonial-container layout-4" data-autoplay="<?php echo esc_attr( empty( $settings['carousel_autoplay'] ) ? 'false' : 'true' ); ?>">
	<div class="tesimonials">
		<?php
		$testimonials = $settings['testimonials_4'];
		foreach ( $testimonials as $testimonial )
		{
			?>
			<div class="testimonial">
				<div class="content">
					<?php echo wp_kses_post( $testimonial['tab_content'] ); ?>
				</div>
			</div>
			<?php
		}
		?>
	</div>
	<div class="slider-nav">
		<?php
		foreach ( $testimonials as $testimonial )
		{
			?>
			<div class="author">
				<div class="thumbnail">
					<?php
					echo tz_get_image_custom_size_html( $testimonial['image']['id'], 68, 68 );
					?>
				</div>
				<div class="infomation">
					<div class="name">
						<?php echo esc_html( $testimonial['testimonial_name'] ); ?>
					</div>
					<div class="job">
						<?php echo esc_html( $testimonial['testimonial_job'] ); ?>
					</div>
				</div>
			</div>
			<?php
		}
		?>
	</div>
</div>