<?php
$link = isset( $settings['link'] ) ? $settings['link'] : '#';
?>
<div class="consux-testimonial-container layout-1">
	<?php
	if ( empty( $settings['hide_quote_icon'] ) )
	{
		echo '<i class="zmdi zmdi-quote"></i>';
	}
	?>

	<div class="tesimonials" data-autoplay="<?php echo esc_attr( empty( $settings['carousel_autoplay'] ) ? 'false' : 'true' ); ?>" data-hide-navigation="<?php echo esc_attr( empty( $settings['hide_navigation'] ) ? 'true' : 'false' ); ?>">
		<?php
		$testimonials = $settings['testimonials'];
		foreach ( $testimonials as $testimonial )
		{
			?>
			<div class="testimonial">
				<div class="rated">
				<?php
				for ( $i = 0 ; $i < 5; $i++ )
				{
					$class = '';
					if ( $i < $testimonial['rate'] )
					{
						$class = 'checked';
					}
					echo sprintf( '<i class="fa fa-star %s"></i>', $class );
				}
				?>
				</div>
				<div class="content">
					<?php echo esc_html( $testimonial['tab_content'] ); ?>
				</div>
				<div class="name">
					<?php echo esc_html( $testimonial['testimonial_name'] ); ?>
				</div>
				<div class="job">
					<?php echo esc_html( $testimonial['testimonial_job'] ); ?>
				</div>
			</div>
			<?php
		}
		?>
	</div>
</div>