<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

class Cosnux_Testimonial_Widget extends Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'consux_testimonial';
	}

	public function get_title()
	{
		return __('Testimonial', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-testimonial-carousel';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{
		$this->tab_content();
		$this->tab_style();
	}

	private function tab_content ()
	{
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Testimonials', 'consux' ),
			]
		);

		$this->add_control(
			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'label_block' => true,
				'default'   =>  'layout-1',
				'options' => [
					'layout-1' => __('Layout 1', 'consux'),
					'layout-2' => __('Layout 2', 'consux'),
					'layout-3' => __('Layout 3', 'consux'),
					'layout-4' => __('Layout 4', 'consux'),
				],
			]
		);

		$this->add_control(
			'hide_quote_icon',
			[
				'type' => Controls_Manager::SWITCHER,
				'label' => __('Hide quote icon', 'consux'),
				'default'   =>  '',
				'condition' =>  [
					'layout!' => ['layout-4']
				]
			]
		);

		$this->add_control(
			'carousel_autoplay',
			[
				'label'	=> esc_html__( 'Autoplay','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  ['layout-1','layout-3']
				]
			]
		);
		$this->add_control(
			'hide_navigation',
			[
				'label'	=> esc_html__( 'Hide Navigation','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);
		$this->add_control(
			'hide_pagination',
			[
				'label'	=> esc_html__( 'Hide Pagination','consux' ),
				'type'	=>	Controls_Manager::SWITCHER,
				'default'	=>	'',
				'condition' =>  [
					'layout'    =>  'layout-3'
				]
			]
		);
		$repeater = new Repeater();

		$repeater->add_control(
			'tab_content',
			[
				'label' => __( 'Content', 'consux' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Accordion Content', 'consux' ),
				'show_label' => false,
			]
		);
		$repeater->add_control(
			'testimonial_name',
			[
				'label' => __( 'Name', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'John Doe',
			]
		);

		$repeater->add_control(
			'testimonial_job',
			[
				'label' => __( 'Job', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'Designer',
			]
		);

		$repeater->add_control(
			'rate',
			[
				'label' => __( 'Rate', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'0' => esc_html__( '0 star' ),
					'1' => esc_html__( '1 star' ),
					'2' => esc_html__( '2 stars' ),
					'3' => esc_html__( '3 stars' ),
					'4' => esc_html__( '4 stars' ),
					'5' => esc_html__( '5 stars' ),
				],
				'default'   =>  '0 star',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'link',
			[
				'label' => __( 'Link', 'elementor' ),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'https://your-link.com', 'elementor' ),
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label' => __( 'Testimonials', 'consux' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'testimonial_name' => __( 'Testimonial #1', 'consux' ),
						'tab_content' => __( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'consux' ),
					],
				],
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$repeater2 = new Repeater();

		$repeater2->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'consux' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater2->add_control(
			'tab_content',
			[
				'label' => __( 'Content', 'consux' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Accordion Content', 'consux' ),
				'show_label' => false,
			]
		);
		$repeater2->add_control(
			'testimonial_name',
			[
				'label' => __( 'Name', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'John Doe',
			]
		);

		$repeater2->add_control(
			'testimonial_job',
			[
				'label' => __( 'Job', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'Designer',
			]
		);

		$repeater2->add_control(
			'rate',
			[
				'label' => __( 'Rate', 'consux' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'0' => esc_html__( '0 star' ),
					'1' => esc_html__( '1 star' ),
					'2' => esc_html__( '2 stars' ),
					'3' => esc_html__( '3 stars' ),
					'4' => esc_html__( '4 stars' ),
					'5' => esc_html__( '5 stars' ),
				],
				'default'   =>  '0 star',
				'label_block' => true,
			]
		);

		$repeater2->add_control(
			'link',
			[
				'label' => __( 'Link', 'elementor' ),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'https://your-link.com', 'elementor' ),
			]
		);

		$this->add_control(
			'testimonials_2',
			[
				'label' => __( 'Testimonials', 'consux' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater2->get_controls(),
				'default' => [
					[
						'testimonial_name' => __( 'Testimonial #1', 'consux' ),
						'tab_content' => __( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'consux' ),
					],
				],
				'condition' =>  [
					'layout'    =>  'layout-2'
				]
			]
		);

		$repeater3 = new Repeater();

		$repeater3->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'consux' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater3->add_control(
			'tab_content',
			[
				'label' => __( 'Content', 'consux' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Accordion Content', 'consux' ),
				'show_label' => false,
			]
		);
		$repeater3->add_control(
			'testimonial_name',
			[
				'label' => __( 'Name', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'John Doe',
			]
		);

		$repeater3->add_control(
			'testimonial_job',
			[
				'label' => __( 'Job', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'Designer',
			]
		);

		$this->add_control(
			'testimonials_3',
			[
				'label' => __( 'Testimonials', 'consux' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater3->get_controls(),
				'default' => [
					[
						'testimonial_name' => __( 'Testimonial #1', 'consux' ),
						'tab_content' => __( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'consux' ),
					],
				],
				'condition' =>  [
					'layout'    =>  'layout-3'
				]
			]
		);

		$repeater4 = new Repeater();

		$repeater4->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'consux' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater4->add_control(
			'tab_content',
			[
				'label' => __( 'Content', 'consux' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Accordion Content', 'consux' ),
				'show_label' => false,
			]
		);
		$repeater4->add_control(
			'testimonial_name',
			[
				'label' => __( 'Name', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'John Doe',
			]
		);

		$repeater4->add_control(
			'testimonial_job',
			[
				'label' => __( 'Job', 'elementor' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'Designer',
			]
		);

		$this->add_control(
			'testimonials_4',
			[
				'label' => __( 'Testimonials', 'consux' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater4->get_controls(),
				'default' => [
					[
						'testimonial_name' => __( 'Testimonial #1', 'consux' ),
						'tab_content' => __( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'consux' ),
					],
				],
				'condition' =>  [
					'layout'    =>  'layout-4'
				]
			]
		);

		$this->end_controls_section();
	}

	private function tab_style ()
	{

		$this->start_controls_section(
			'section_icon_style',
			[
				'label' => __( 'Icon', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' =>  [
					'layout!'   =>  'layout-4'
				]
			]
		);

		$this->add_control(
			'quote_icon_color',
			[
				'label' => __( 'Quote Icon Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-testimonial-container.layout-1 > i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-testimonial-container.layout-3 .testimonial .wrapper .author i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Star Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#fab702',
				'selectors' => [
					'{{WRAPPER}} .consux-testimonial-container .testimonial .rated i.checked' => 'color: {{VALUE}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->add_responsive_control(
			'icon_space',
			[
				'label' =>  esc_html__( 'Space', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'size_units'    =>  ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' =>  [
						'min' => 0,
						'max' => 100,
						'step'  =>  1
					]
				],
				'default'   =>  [
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .consux-testimonial-container .testimonial .rated' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' =>  [
					'layout'    =>  'layout-1'
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_title',
			[
				'label' => __( 'Content', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_color',
			[
				'label' => __( 'Content Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#222',
				'selectors' => [
					'{{WRAPPER}} .consux-testimonial-container .testimonial .content' => 'color: {{VALUE}};',
				],
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .consux-testimonial-container .testimonial .content',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_responsive_control(
			'content_space',
			[
				'label' =>  esc_html__( 'Space', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'size_units'    =>  ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' =>  [
						'min' => 0,
						'max' => 100,
						'step'  =>  1
					]
				],
				'default'   =>  [
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .consux-testimonial-container .testimonial .content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'name_color',
			[
				'label' => __( 'Name Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#7eb729',
				'separator' =>  'before',
				'selectors' => [
					'{{WRAPPER}} .consux-testimonial-container .testimonial .name' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-testimonial-container.layout-4 .author .infomation .name' => 'color: {{VALUE}};',
				],
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_typography',
				'selector' => '{{WRAPPER}} .consux-testimonial-container .testimonial .name',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'condition' =>  [
					'layout!'   =>  'layout-4'
				]
			]
		);

		$this->add_responsive_control(
			'name_space',
			[
				'label' =>  esc_html__( 'Space', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'size_units'    =>  ['px', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
					'%' =>  [
						'min' => 0,
						'max' => 100,
						'step'  =>  1
					]
				],
				'default'   =>  [
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .consux-testimonial-container .testimonial .name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' =>  [
					'layout!'   =>  'layout-4'
				]
			]
		);

		$this->add_control(
			'job_color',
			[
				'label' => __( 'Job Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#777',
				'separator' =>  'before',
				'selectors' => [
					'{{WRAPPER}} .consux-testimonial-container .testimonial .job' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-testimonial-container.layout-4 .author.slick-current .infomation .job' => 'color: {{VALUE}};',
				],
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'job_typography',
				'selector' => '{{WRAPPER}} .consux-testimonial-container .testimonial .job',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'condition' =>  [
					'layout!'   =>  'layout-4'
				]
			]
		);

		$this->end_controls_section();
	}
	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) . '/' . $settings['layout'] . '.php';
	}
}

$widgets_manager->register_widget_type(new \Cosnux_Testimonial_Widget());