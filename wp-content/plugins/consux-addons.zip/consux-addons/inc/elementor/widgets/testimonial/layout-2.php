<?php
use Elementor\Group_Control_Image_Size;
$link = isset( $settings['link'] ) ? $settings['link'] : '#';
?>
<div class="consux-testimonial-container layout-2">
	<div class="tesimonials" data-autoplay="<?php echo esc_attr( empty( $settings['carousel_autoplay'] ) ? 'false' : 'true' ); ?>" data-hide-navigation="<?php echo esc_attr( empty( $settings['hide_navigation'] ) ? 'true' : 'false' ); ?>">
		<?php
		$testimonials = $settings['testimonials_2'];
		foreach ( $testimonials as $testimonial )
		{
			?>
			<div class="testimonial">
				<div class="content">
					<?php
					if ( empty( $settings['hide_quote_icon'] ) )
					{
						echo '<i class="zmdi zmdi-quote"></i>';
					}
					?>
					<?php echo esc_html( $testimonial['tab_content'] ); ?>
				</div>
				<div class="author d-flex align-items-center">
					<div class="thumbnail">
						<?php
						echo tz_get_image_custom_size_html( $testimonial['image']['id'], 70, 70 );
						?>
					</div>
					<div class="infomation">
						<div class="name">
							<?php echo esc_html( $testimonial['testimonial_name'] ); ?>
						</div>
						<div class="job">
							<?php echo esc_html( $testimonial['testimonial_job'] ); ?>
						</div>
					</div>
				</div>
			</div>
			<?php
		}
		?>
	</div>
</div>