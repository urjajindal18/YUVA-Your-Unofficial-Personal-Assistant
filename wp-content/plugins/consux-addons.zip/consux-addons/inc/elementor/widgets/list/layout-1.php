<div class="consux-custom-list-container <?php echo esc_attr( $settings['layout'] ); ?>">
	<ul>
		<?php
		foreach ( $settings['list_info'] as $line )
		{
			$url = isset( $line['url']['url'] ) ? $line['url']['url']: '#';
			$target = '';
			$class = '';
			if ( ! empty( $line['url']['is_external'] ) )
			{
				$target = sprintf( 'target="_blank"' );
			}
			if ( $line['active'] )
			{
				$class = sprintf( 'class="current-post"' );
			}
			?>
			<li><a <?php echo $target; ?> <?php echo $class; ?> href="<?php echo esc_url( $url ); ?>"><?php echo $line['info']; ?></a></li>
			<?php
		}
		?>
	</ul>
</div>