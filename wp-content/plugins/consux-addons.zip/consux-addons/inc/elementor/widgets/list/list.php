<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class Consux_Custom_List extends Widget_Base {

	public function get_name()
	{
		return 'consux_list';
	}

	public function get_title()
	{
		return esc_html__('Custom List', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-menu-bar';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls()
	{
		$this->tab_content();
		$this->tab_style();
	}

	private function tab_content()
	{
		$this->start_controls_section(
			'section_list_content',
			[
				'label' => esc_html__('List', 'consux'),
			]
		);

		$this->add_control(
			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'default' => 'layout-1',
				'label_block' => true,
				'options' => [
					'layout-1' => __('Layout 1', 'consux'),
				],
			]
		);

		$repeater = new Elementor\Repeater();

		$repeater->add_control(
			'info',
			[
				'label' =>  esc_html__( 'Information', 'consux' ),
				'type'  =>  Controls_Manager::TEXT
			]
		);

		$repeater->add_control(
			'url',
			[
				'label' =>  esc_html__( 'Url', 'consux' ),
				'type'  =>  Controls_Manager::URL
			]
		);

		$repeater->add_control(
			'active',
			[
				'label' =>  esc_html__( 'Active', 'consux' ),
				'type'  =>  Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'list_info',
			[
				'label' =>  esc_html__( 'List Information', 'consux' ),
				'type'  =>  Controls_Manager::REPEATER,
				'fields'    =>  $repeater->get_controls(),
				'default'   =>  [
					'info'  =>  esc_html__( 'List Information', 'consux' ),
				]
			]
		);
		$this->end_controls_section();
	}
	private function tab_style()
	{
		$this->start_controls_section(
			'pricing_list_style',
			[
				'label' =>  esc_html__( 'List', 'consux' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'list_typography',
				'selector' => '{{WRAPPER}} .consux-custom-list-container ul li a',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);

		$this->start_controls_tabs( 'list_style_tabs' );

		$this->start_controls_tab(
			'normal',
			[
				'label'	=> esc_html__( 'Normal', 'consux' ),
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => __( 'Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#eee',
				'selectors' => [
					'{{WRAPPER}} .consux-custom-list-container ul li a' => 'background-color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'border_color',
			[
				'label' => __( 'Border Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#d0d0d0',
				'selectors' => [
					'{{WRAPPER}} .consux-custom-list-container ul li a:before' => 'background-color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => __( 'Text Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#222',
				'selectors' => [
					'{{WRAPPER}} .consux-custom-list-container ul li a' => 'color: {{VALUE}};',
				],
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
			]
		);

		$this->end_controls_tab(); // end tab normal
		$this->start_controls_tab(
			'hover',
			[
				'label'	=> esc_html__( 'Hover', 'consux' ),
			]
		);

		$this->add_control(
			'background_color_hover',
			[
				'label' => __( 'Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-custom-list-container ul li a:hover:after' => 'background-color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'border_color_hover',
			[
				'label' => __( 'Border Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#7eb729',
				'selectors' => [
					'{{WRAPPER}} .consux-custom-list-container ul li a:hover:before' => 'background-color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'text_color_hover',
			[
				'label' => __( 'Text Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   =>  '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-custom-list-container ul li a:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-custom-list-container ul li a.current-post' => 'color: {{VALUE}};',
				],
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
			]
		);

		$this->end_controls_tab(); // end tab hover
		$this->end_controls_tabs(); // end service_style_tabs

		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) .'/' . $settings['layout'] . '.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_Custom_List());