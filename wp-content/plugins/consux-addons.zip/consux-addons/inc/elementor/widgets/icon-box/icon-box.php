<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

class Consux_Icon_Box extends Widget_Base {

	public function get_name()
	{
		return 'consux_icon_box';
	}

	public function get_title()
	{
		return __('Icon Box', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-icon-box';
	}

	/**
	 * Retrieve the list of scripts the counter widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.3.0
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'jquery-numerator' ];
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		// Content Tab
		$this->tab_content();
		// Tab Style
		$this->tab_style();
	}

	// section and element on tab content
	private function tab_content ()
	{
		$this->start_controls_section(
			'section_icon_box',
			[
				'label' => __('Icon Box', 'consux'),
			]
		);
		$this->add_control(

			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'default' => 'layout-inline',
				'label_block' => true,
				'options' => [
					'layout-inline' => __('Inline', 'consux'),
					'layout-box' => __('Box', 'consux'),
				],
			]
		);

		$this->add_control(
			'box_type',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Box Type', 'consux'),
				'default' => 'default',
				'label_block' => true,
				'options' => [
					'default' => __('Default', 'consux'),
					'modern' => __('Modern', 'consux'),
				],
				'condition' =>  [
					'layout'    =>  'layout-box'
				]
			]
		);

		$this->add_control(
			'icon_type',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Icon Type', 'consux'),
				'default' => 'fontawesome',
				'label_block' => true,
				'options' => [
					'fontawesome' => esc_html__('Fontawesome', 'consux'),
					'flaticon' => esc_html__('Flaticon', 'consux'),
					'icomoon' => esc_html__('Icomoon', 'consux'),
				],
			]
		);

		$this->add_control(
			'fontawesome',
			[
				'label' => esc_html__( 'Icon', 'consux' ),
				'type'  => Controls_Manager::ICON,
				'default' => 'fa fa-star',
				'condition'	=>	[
					'icon_type'	=>	'fontawesome'
				]
			]
		);

		$this->add_control(
			'flaticon',
			[
				'label' => esc_html__( 'Icon', 'consux' ),
				'type'  => 'flaticon',
				'default'	=>	'flaticon-003-development',
				'condition'	=>	[
					'icon_type'	=>	'flaticon'
				]
			]
		);

		$this->add_control(
			'icomoon',
			[
				'label' => esc_html__( 'Icomoon', 'consux' ),
				'type'  => 'icomoon',
				'condition'	=>	[
					'icon_type'	=>	'icomoon'
				]
			]
		);

		$this->add_control(
			'title_text',
			[
				'label' =>  esc_html__( 'Title & Description', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'This is the heading', 'consux' ),
				'placeholder' => __( 'Enter your title', 'consux' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'description_text',
			[
				'label' =>  esc_html__( 'Description', 'consux' ),
				'type'  => Controls_Manager::TEXTAREA,
				'default' => __( 'This is the heading', 'consux' ),
				'placeholder' => __( 'Enter your title', 'consux' ),
				'label_block' => true,
				'rows' => 10,
				'default' => __( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'consux' ),
			]
		);


		$this->add_control(
			'link_url',
			[
				'label' =>  esc_html__( 'URL', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'label_block' => true,
				'condition'	=>	[
					'layout' => 'layout-box'
				]
			]
		);

		$this->add_control(
			'enable_header_counter',
			[
				'label' =>  esc_html__( 'Make title counter', 'consux' ),
				'type'  =>  Controls_Manager::SWITCHER,
				'condition' =>  [
					'layout'    =>  'layout-box'
				]
			]
		);

		$this->add_control(
			'icon_position',
			[
				'label' => __( 'Icon Position', 'consux' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'top',
				'options' => [
					'left' => [
						'title' => __( 'Left', 'consux' ),
						'icon' => 'fa fa-align-left',
					],
					'top' => [
						'title' => __( 'Top', 'consux' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'consux' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'condition' =>  [
					'layout'    =>  'layout-box'
				]
			]
		);

		$this->end_controls_section();
	}

	// section and element on tab style
	private function tab_style()
	{
		$this->start_controls_section(
			'section_style_container',
			[
				'label' =>  esc_html__( 'Container', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
				'condition' =>  [
					'layout' => 'layout-box',
				]
			]
		);
		$this->add_control(
			'container_bg_color',
			[
				'label' => __( 'Container Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'container_bg_hover_color',
			[
				'label' => __( 'Container Background Hover Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'container_padding',
			[
				'label' => __( 'Padding', 'butler' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'box_border',
				'selector' => '{{WRAPPER}} .consux-icon_box_wrapper.layout-box',
				'condition'	=>	[
					'layout'	=>	'layout-box'
				]
			]
		);
		$this->add_responsive_control(
			'box_border_radius',
			[
				'label' => __( 'Border Radius', 'consux' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selector' => '{{WRAPPER}} .consux-icon_box_wrapper.layout-box',
				'condition'	=>	[
					'layout'	=>	'layout-box'
				]
			]
		);

		$this->end_controls_section(); //section_style_container

		$this->start_controls_section(
			'section_style_icon',
			[
				'label' =>  esc_html__( 'Icon', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'primary_color',
			[
				'label' => __( 'Icon Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper .icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'primary_color_hover',
			[
				'label' => esc_html__( 'Icon Hover Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper:hover .icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_space_top',
			[
				'label' => esc_html__( 'Spacing Top', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0,
				],
				'range' => [
					'px' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box .icon ' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition'	=>	[
					'layout'	=>	'layout-box'
				]
			]
		);

		$this->add_responsive_control(
			'icon_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 15,
				],
				'range' => [
					'px' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-inline .icon ' => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box.icon-top .icon ' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box.icon-left .icon ' => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box.icon-right .icon ' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => esc_html__( 'Size', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 6,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper .icon.fontawesome i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .consux-icon_box_wrapper .icon.flaticon i:before' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .consux-icon_box_wrapper .icon.icomoon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();		// End Icon section

		// Content Section Style
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE
			]
		);

		$this->add_responsive_control(
			'content_align',
			[
				'label' => __( 'Align', 'consux' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'text-center',
				'options' => [
					'left' => [
						'title' => __( 'Left', 'consux' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'consux' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'consux' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box' => 'text-align: {{VALUE}}',
				],
				'layout' => [
					'layout' => 'layout-box',
				],
			]
		);

		$this->add_control(
			'title_primary_color',
			[
				'label' => esc_html__( 'Title Color', 'consux' ),
				'type'  => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-inline h4' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box h4' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box h4 a' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'title_primary_hover_color',
			[
				'label' => esc_html__( 'Title Hover Color', 'consux' ),
				'type'  => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-inline:hover h4' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box:hover h4' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box:hover h4 a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_space',
			[
				'label' => esc_html__( 'Title Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-inline h4' => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box h4' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .consux-icon_box_wrapper h4',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'description_primary_color',
			[
				'label' => esc_html__( 'Description Color', 'consux' ),
				'type'  => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-inline .description' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'description_primary_hover_color',
			[
				'label' => esc_html__( 'Description Hover Color', 'consux' ),
				'type'  => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-inline:hover .description' => 'color: {{VALUE}};',
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box:hover .description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'selector' => '{{WRAPPER}} .consux-icon_box_wrapper.layout-inline .description',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'condition' => [
					'layout'	=> 'layout-inline'
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_box_typography',
				'selector' => '{{WRAPPER}} .consux-icon_box_wrapper.layout-box .description',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'condition' => [
					'layout'	=> 'layout-box'
				]
			]
		);

		$this->add_responsive_control(
			'description_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .consux-icon_box_wrapper.layout-box .description' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' =>	[
					'layout' => 'layout-box'
				]
			]
		);

		$this->end_controls_section(); // End Content Section Style
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) .'/' . $settings['layout'] . '.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_Icon_Box());