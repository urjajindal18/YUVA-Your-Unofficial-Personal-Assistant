<?php
$icon_position = sprintf( 'icon-%s', $settings['icon_position'] );
$counter = '';
if  ( $settings['enable_header_counter'] )
{
    $counter = 'counter';
}
?>
<div class="consux-icon_box_wrapper layout-box <?php echo esc_attr( $icon_position ); ?> <?php echo esc_attr( $settings['box_type'] ); ?>">
	<?php
	$icon_type = $settings['icon_type'];
	if ( $settings[$icon_type] )
	{
	?>
		<div class="icon <?php echo esc_attr( $icon_type ); ?>"><i class="<?php echo esc_attr( $settings[$icon_type] ); ?>"></i></div>
	<?php
	}
	?>
	<div class="information">
		<?php
		$title = esc_html( $settings['title_text'] );
		if ( $settings['link_url'] )
		{
			$link_url = $settings['link_url'] ? $settings['link_url'] : '#';
			?>

			<?php
			$title = sprintf( '<a class="box-link" href="%s">%s</a>', esc_url( $link_url ), esc_html( $settings['title_text'] ) );
		}
		?>
		<h4 class="<?php echo esc_attr( $counter ); ?>" data-value-to="<?php echo esc_attr( $title ); ?>"><?php echo $settings['enable_header_counter'] ? 0 : $title; ?></h4>
		<div class="description">
			<?php echo wp_kses_post( $settings['description_text'] ); ?>
		</div>
	</div>
	<?php
	if  ( isset( $link_url ) )
	{
    ?>
            <a class="icon-link" href="<?php echo esc_url( $link_url ); ?>"><i class="zmdi zmdi-long-arrow-right"></i></a>
    <?php
	}
	?>
</div>