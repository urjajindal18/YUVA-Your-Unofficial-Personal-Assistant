<div class="consux-icon_box_wrapper layout-inline d-flex align-items-center">
	<?php
	$icon_type = $settings['icon_type'];
	if ( $settings[$icon_type] )
	{
	?>
		<div class="icon <?php echo esc_attr( $icon_type ); ?>"><i class="<?php echo esc_attr( $settings[$icon_type] ); ?>"></i></div>
	<?php
	}
	?>
	<h4><?php echo esc_html( $settings['title_text'] ); ?></h4>
	<div class="description">
		<?php echo esc_html( $settings['description_text'] ); ?>
	</div>
</div>