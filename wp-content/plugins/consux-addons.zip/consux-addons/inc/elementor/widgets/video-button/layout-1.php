<?php
$link = isset( $settings['link'] ) ? $settings['link'] : '#';
?>
<div class="video-button-container layout-1 d-flex align-items-center">
	<a class="play-link" href="<?php echo esc_url( $link ); ?>"><i class="<?php echo esc_attr( $settings['icon'] ); ?>"></i></a>
	<?php
	if ( $settings['text_intro'] )
	{
		?>
		<span class="text-intro"><?php echo wp_kses_post( $settings['text_intro'] ); ?></span>
		<?php
	}
	?>
</div>