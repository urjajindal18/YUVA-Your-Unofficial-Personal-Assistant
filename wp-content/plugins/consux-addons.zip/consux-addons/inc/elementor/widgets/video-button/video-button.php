<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

class Elementor_Video_Button extends Widget_Base {

	private $i10n;

	public function get_name()
	{
		return 'consux_video_button';
	}

	public function get_title()
	{
		return __('Video Button', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-play';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_video_button',
			[
				'label' => __('Button', 'consux'),
			]
		);

		$this->add_control(
			'icon',
			[
				'label' =>  esc_html__( 'Icon', 'consux' ),
				'type'  =>  Controls_Manager::ICON,
				'default'   =>  'fa fa-play'
			]
		);

		$this->add_control(
			'link',
			[
				'label' => __( 'URL', 'consux' ),
				'type' => Controls_Manager::TEXT,
				'autocomplete' => false,
				'label_block' => true,
				'placeholder' => __( 'Enter your URL', 'consux' ),
			]
		);

		$this->add_control(
			'text_intro',
			[
				'label' => __( 'Text Introduction', 'consux' ),
				'type' => Controls_Manager::TEXTAREA,
				'autocomplete' => false,
				'label_block' => true,
			]
		);

		$this->end_controls_section(); // End section content

		$this->start_controls_section(
			'section_video_button_style',
			[
				'label' => esc_html__( 'Style', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' =>  esc_html__( 'Icon color', 'consux' ),
				'type'  =>  Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'   =>  '#7eb729',
				'selectors'  =>  [
					'{{WRAPPER}} .video-button-container .play-link i'  => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => esc_html__( 'Size', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .video-button-container .play-link i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'position',
			[
				'label' => __( 'Icon Position', 'consux' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'flex-start',
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'butler' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Top', 'butler' ),
						'icon' => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'butler' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .video-button-container' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'background_color',
			[
				'label' => __( 'Background Color', 'consux' ),
				'type' => Controls_Manager::COLOR,
				'default'   => '#fff',
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_4,
				],
				'selectors' => [
					'{{WRAPPER}} .video-button-container .play-link' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => __( 'Border Radius', 'consux' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .video-button-container .play-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .video-button-container .play-link',
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label' => __( 'Padding', 'consux' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					 '{{WRAPPER}} .video-button-container .play-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section(); // End section style

		$this->start_controls_section(
			'section_text_style',
			[
				'label' => esc_html__( 'Text Style', 'butler' ),
				'tab'   =>  Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' =>  esc_html__( 'Text color', 'butler' ),
				'type'  =>  Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'   =>  '#fff',
				'selectors'  =>  [
					'{{WRAPPER}} .video-button-container .text-intro'  => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'selector' => '{{WRAPPER}} .video-button-container .text-intro',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->end_controls_section(); // End section style

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname( __FILE__ ) . '/layout-1.php';
	}

}
$widgets_manager->register_widget_type(new \Elementor_Video_Button());