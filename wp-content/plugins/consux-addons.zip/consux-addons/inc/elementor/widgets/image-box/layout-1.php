<?php
use Elementor\Group_Control_Image_Size;
use Elementor\Control_Media;
use Elementor\Plugin;

?>
<div class="butler-image-box layout-1 d-md-flex <?php echo esc_attr( $settings['image_side'] ); ?>">
	<div class="left-side">
		<?php
		if ( isset( $settings['image']['url'] ) )
		{
			?>
			<?php
			$image_url = Group_Control_Image_Size::get_attachment_image_src( $settings['image']['id'], 'image_size', $settings );
//			$image_html = '<img src="' . esc_attr( $image_url ) . '" alt="' . esc_attr( Control_Media::get_image_alt( $settings['image'] ) ) . '" />';
//			echo $image_html;
			$style = sprintf( 'style="background-image:url(%s)"', esc_url( $image_url ) );
			?>
			<div <?php echo $style;?> class="thumbnail hover-zoomin">
			</div>
			<?php
		}
		?>
	</div>
	<div class="right-side">
		<div class="information">
			<h3><?php echo esc_html( $settings['title_text'] ); ?></h3>
			<div class="description"><?php echo esc_html( $settings['description_text'] ); ?></div>
			<?php
			if ( $settings['more_text'] )
			{
				$url = $settings['more_link'] ? $settings['more_link'] : '#';
			?>
				<a class="read-more" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $settings['more_text'] ); ?><i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
			<?php
			}
			?>
		</div>
	</div>
</div>