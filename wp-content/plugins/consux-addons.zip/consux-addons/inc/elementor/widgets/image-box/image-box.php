<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;

class Consux_Image_Box extends Widget_Base {

	public function get_name()
	{
		return 'consux_image_box';
	}

	public function get_title()
	{
		return __('Image Box', 'consux');
	}

	public function get_icon()
	{
		return 'eicon-image-box';
	}

	public function get_categories() {
		return ['consux-category'];
	}

	protected function _register_controls() {
		// Content Tab
		$this->tab_content();
		// Tab Style
		$this->tab_style();
	}

	// section and element on tab content
	private function tab_content ()
	{
		$this->start_controls_section(
			'section_image_box',
			[
				'label' => __('Image Box', 'consux'),
			]
		);
		$this->add_control(
			'layout',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Choose Layout', 'consux'),
				'default' => 'layout-1',
				'label_block' => true,
				'options' => [
					'layout-1' => __('Image Side', 'consux'),
				],
			]
		);

		$this->add_control(
			'image_side',
			[
				'type' => Controls_Manager::SELECT,
				'label' => __('Image Side', 'consux'),
				'default' => 'left',
				'label_block' => true,
				'options' => [
					'left' => __('Left Side', 'consux'),
					'right' => __('Right Side', 'consux'),
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label' => __( 'Choose Image', 'consux' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);


		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name' => 'image_size', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
				'default' => 'thumbnail',
				'separator' => 'none',
			]
		);

		$this->add_control(
			'title_text',
			[
				'label' =>  esc_html__( 'Title & Description', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => __( 'This is the heading', 'consux' ),
				'placeholder' => __( 'Enter your title', 'consux' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'description_text',
			[
				'label' =>  esc_html__( 'Description', 'consux' ),
				'type'  => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your title', 'consux' ),
				'label_block' => true,
				'rows' => 10,
				'default' => __( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'consux' ),
			]
		);

		$this->add_control(
			'more_text',
			[
				'label' =>  esc_html__( 'Read More Text', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( 'Read More', 'consux' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'more_link',
			[
				'label' =>  esc_html__( 'Read More Link', 'consux' ),
				'type'  => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( '#', 'consux' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();
	}

	// section and element on tab style
	private function tab_style()
	{
		// Content Section Style
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content', 'consux' ),
				'tab'   =>  Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'container_bg_color',
			[
				'label' => esc_html__( 'Right Side BG Color', 'consux' ),
				'type'  => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'   =>  '#222',
				'selectors' => [
					'{{WRAPPER}} .butler-image-box.layout-1 .right-side' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_primary_color',
			[
				'label' => esc_html__( 'Title Color', 'consux' ),
				'type'  => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'   =>  '#fff',
				'selectors' => [
					'{{WRAPPER}} .butler-image-box.layout-1 .right-side .information h3' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'title_space',
			[
				'label' => esc_html__( 'Title Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'size' => 11,
				],
				'selectors' => [
					'{{WRAPPER}} .butler-image-box.layout-1 .right-side .information h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .butler-image-box.layout-1 .right-side .information h3',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_control(
			'description_primary_color',
			[
				'label' => esc_html__( 'Description Color', 'consux' ),
				'type'  => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default'   =>  '#fff',
				'selectors' => [
					'{{WRAPPER}} .butler-image-box.layout-1 .right-side .information .description' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'selector' => '{{WRAPPER}} .butler-image-box.layout-1 .right-side .information .description',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->add_responsive_control(
			'description_space',
			[
				'label' => esc_html__( 'Spacing', 'consux' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'size' => 26,
				],
				'selectors' => [
					'{{WRAPPER}} .butler-image-box.layout-1 .right-side .information .description' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section(); // End Content Section Style
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		require dirname(__FILE__) .'/' . $settings['layout'] . '.php';
	}

}
$widgets_manager->register_widget_type(new \Consux_Image_Box());