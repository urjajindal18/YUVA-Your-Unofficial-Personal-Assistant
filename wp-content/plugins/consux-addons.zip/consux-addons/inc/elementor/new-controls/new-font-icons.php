<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Adding custom icon to icon control in Elementor
 */
function consux_add_more_icon( $controls_registry ) {
	// Get existing icons
	$icons = $controls_registry->get_control( 'icon' )->get_settings( 'options' );
	// Append new icons
	$new_icons = array_merge(
		array(
			'zmdi zmdi-play' => 'iconic play',
			'zmdi zmdi-check-square' => 'iconic check square',
			'zmdi zmdi-thumb-up' => 'iconic thumb-up',
		),
		$icons
	);
	// Then we set a new list of icons as the options of the icon control
	$controls_registry->get_control( 'icon' )->set_settings( 'options', $new_icons );
}

add_action( 'elementor/controls/controls_registered', 'consux_add_more_icon', 10, 1 );

/* New Icon Control - Flat Icon */
class Consux_Flaticon_Control extends \Elementor\Base_Data_Control {

	public function get_type() 
	{
		return 'flaticon';
	}

	/**
	 * Get icons.
	 *
	 * Retrieve all the available icons.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @return array Available icons.
	 */
	public static function get_icons() 
	{
		return [
			'flaticon-001-strategy-5'	=>	'strategy-5',
			'flaticon-002-strategy-4'	=>	'strategy-4',
			'flaticon-003-development'	=>	'development',
			'flaticon-004-maze'	=>	'maze',
			'flaticon-005-analysis-1'	=>	'analysis-1',
			'flaticon-006-handshake'	=>	'handshake',
			'flaticon-007-strategy-3'	=>	'strategy-3',
			'flaticon-008-develop'	=>	'develop',
			'flaticon-009-communications'	=>	'communications',
			'flaticon-010-analysis'	=>	'analysis',
			'flaticon-011-strategies'	=>	'strategies',
			'flaticon-012-direction'	=>	'direction',
			'flaticon-013-vision'	=>	'vision',
			'flaticon-014-setting-1'	=>	'setting-1',
			'flaticon-015-network'	=>	'network',
			'flaticon-016-strategy-2'	=>	'strategy-2',
			'flaticon-017-skills'	=>	'skills',
			'flaticon-018-pie-graphic'	=>	'pie-graphic',
			'flaticon-019-workers'	=>	'workers',
			'flaticon-020-pyramid'	=>	'pyramid',
			'flaticon-021-management-1'	=>	'management-1',
			'flaticon-022-idea'	=>	'idea',
			'flaticon-023-marketing'	=>	'marketing',
			'flaticon-024-organization-2'	=>	'organization-2',
			'flaticon-025-setting'	=>	'setting',
			'flaticon-026-chess'	=>	'chess',
			'flaticon-027-strategy-1'	=>	'strategy-1',
			'flaticon-029-choose'	=>	'choose',
			'flaticon-030-training-1'	=>	'training-1',
			'flaticon-031-target'	=>	'target',
			'flaticon-032-training'	=>	'training',
			'flaticon-033-chart'	=>	'chart',
			'flaticon-034-organization'	=>	'organization',
			'flaticon-035-start'	=>	'start',
			'flaticon-036-selective'	=>	'selective',
			'flaticon-037-timer'	=>	'timer',
			'flaticon-038-creative'	=>	'creative',
			'flaticon-039-people'	=>	'people',
			'flaticon-040-progress'	=>	'progress',
			'flaticon-041-management'	=>	'management',
			'flaticon-042-analytics'	=>	'analytics',
			'flaticon-043-value'	=>	'value',
			'flaticon-044-planning'	=>	'planning',
			'flaticon-045-human-resources'	=>	'human-resources',
			'flaticon-046-tie'	=>	'tie',
			'flaticon-047-business'	=>	'business',
			'flaticon-048-strategy'	=>	'strategy',
			'flaticon-049-options'	=>	'options',
			'flaticon-050-achievement'	=>	'achievement',
		];

	}

	/**
	 * Get icons control default settings.
	 *
	 * Retrieve the default settings of the icons control. Used to return the default
	 * settings while initializing the icons control.
	 *
	 * @since 1.0.0
	 * @access protected
	 *
	 * @return array Control default settings.
	 */
	protected function get_default_settings() {
		return [
			'options' => self::get_icons(),
			'include' => '',
			'exclude' => '',
		];
	}

	/**
	 *  method registers and enqueues scripts and styles used by the control.
	 */
	public function enqueue()
	{
		wp_enqueue_script( 'flaticon', CONSUX_TF_ELEMENTOR_URL . 'assets/js/load-select2.js', ['jquery'], '1.0.0' );
	}

	/**
	 * Render icons control output in the editor.
	 *
	 * Used to generate the control HTML in the editor using Underscore JS
	 * template. The variables for the class are available using `data` JS
	 * object.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function content_template() {
		$control_uid = $this->get_control_uid();
		?>
		<div class="elementor-control-field">
			<label for="<?php echo $control_uid; ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<div class="elementor-control-input-wrapper">
				<select id="<?php echo $control_uid; ?>" class="custom-control-icon2" data-setting="{{ data.name }}" data-placeholder="<?php echo __( 'Select Icon', 'elementor' ); ?>">
					<option value=""><?php echo __( 'Select Icon', 'elementor' ); ?></option>
					<# _.each( data.options, function( option_title, option_value ) { #>
						<option value="{{ option_value }}" data-icon="{{ option_value }}">{{{ option_title }}}</option>
						<# } ); #>
				</select>
			</div>
		</div>
		<# if ( data.description ) { #>
			<div class="elementor-control-field-description">{{ data.description }}</div>
			<# } #>
		<?php
	}
}

/* New Icon Control - IcoMoon */
class Consux_IcoMoon_Control extends \Elementor\Base_Data_Control {

	public function get_type()
	{
		return 'icomoon';
	}

	/**
	 * Get icons.
	 *
	 * Retrieve all the available icons.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @return array Available icons.
	 */
	public static function get_icons()
	{
		return [
			'icon-binoculars' => 'binoculars',
			'icon-businessman' => 'businessman',
			'icon-businessman-1' => 'businessman-1',
			'icon-businessman-2' => 'businessman-2',
			'icon-businessman-3' => 'businessman-3',
			'icon-businessman-4' => 'businessman-4',
			'icon-businessman-5' => 'businessman-5',
			'icon-businessman-6' => 'businessman-6',
			'icon-businessman-7' => 'businessman-7',
			'icon-businessman-8' => 'businessman-8',
			'icon-businessman-9' => 'businessman-9',
			'icon-businessman-10' => 'businessman-10',
			'icon-businessman-11' => 'businessman-11',
			'icon-businessman-12' => 'businessman-12',
			'icon-businessman-13' => 'businessman-13',
			'icon-businessman-14' => 'businessman-14',
			'icon-businessman-15' => 'businessman-15',
			'icon-businessman-16' => 'businessman-16',
			'icon-businessman-17' => 'businessman-17',
			'icon-businessmen' => 'businessmen',
			'icon-businessmen-1' => 'businessmen-1',
			'icon-businesswoman' => 'businesswoman',
			'icon-businesswoman-1' => 'businesswoman-1',
			'icon-businesswoman-2' => 'businesswoman-2',
			'icon-customer-service' => 'customer-service',
			'icon-file' => 'file',
			'icon-file-1' => 'file-1',
			'icon-group' => 'group',
			'icon-head' => 'head',
			'icon-head-1' => 'head-1',
			'icon-head-2' => 'head-2',
			'icon-head-3' => 'head-3',
			'icon-hierarchical-structure' => 'hierarchical-structure',
			'icon-hierarchical-structure-1' => 'hierarchical-structure-1',
			'icon-hierarchical-structure-2' => 'hierarchical-structure-2',
			'icon-hierarchical-structure-3' => 'hierarchical-structure-3',
			'icon-hierarchical-structure-4' => 'hierarchical-structure-4',
			'icon-id-card' => 'id-card',
			'icon-id-card-1' => 'id-card-1',
			'icon-id-card-2' => 'id-card-2',
			'icon-magnifying-glass' => 'magnifying-glass',
			'icon-monitor' => 'monitor',
			'icon-networking' => 'networking',
			'icon-networking-1' => 'networking-1',
			'icon-networking-2' => 'networking-2',
			'icon-networking-3' => 'networking-3',
			'icon-networking-4' => 'networking-4',
			'icon-networking-5' => 'networking-5',
			'icon-networking-6' => 'networking-6',
			'icon-networking-7' => 'networking-7',
			'icon-networking-8' => 'networking-8',
			'icon-networking-9' => 'networking-9',
			'icon-networking-10' => 'networking-10',
			'icon-networking-11' => 'networking-11',
			'icon-networking-12' => 'networking-12',
			'icon-networking-13' => 'networking-13',
			'icon-networking-14' => 'networking-14',
			'icon-networking-15' => 'networking-15',
			'icon-networking-16' => 'networking-16',
			'icon-networking-17' => 'networking-17',
			'icon-networking-18' => 'networking-18',
			'icon-networking-19' => 'networking-19',
			'icon-networking-20' => 'networking-20',
			'icon-networking-21' => 'networking-21',
			'icon-networking-22' => 'networking-22',
			'icon-networking-23' => 'networking-23',
			'icon-networking-24' => 'networking-24',
			'icon-networking-25' => 'networking-25',
			'icon-networking-26' => 'networking-26',
			'icon-networking-27' => 'networking-27',
			'icon-networking-28' => 'networking-28',
			'icon-pie-chart' => 'pie-chart',
			'icon-placeholder' => 'placeholder',
			'icon-placeholder-1' => 'placeholder-1',
			'icon-settings' => 'settings',
			'icon-settings-1' => 'settings-1',
			'icon-settings-2' => 'settings-2',
			'icon-settings-3' => 'settings-3',
			'icon-settings-4' => 'settings-4',


			'icon-settings-5' => 'settings-5',


			'icon-settings-6' => 'settings-6',


			'icon-settings-7' => 'settings-7',


			'icon-settings-8' => 'settings-8',


			'icon-smartphone' => 'smartphone',


			'icon-smartphone-1' => 'smartphone-1',


			'icon-stats' => 'stats',


			'icon-telephone' => 'telephone',


			'icon-worldwide' => 'worldwide',


			'icon-worldwide-1' => 'worldwide-1',


			'icon-worldwide-2' => 'worldwide-2',


			'icon-light-bulb-1' => 'light-bulb-1',


			'icon-sprout' => 'sprout',


			'icon-goal' => 'goal',


			'icon-visualization' => 'visualization',


			'icon-trophy' => 'trophy',


			'icon-panel' => 'panel',


			'icon-briefcase' => 'briefcase',


			'icon-bar-chart' => 'bar-chart',


			'icon-startup' => 'startup',


			'icon-dollar' => 'dollar',


			'icon-thinking' => 'thinking',


			'icon-management' => 'management',


			'icon-time' => 'time',


			'icon-light-bulb' => 'light-bulb',


			'icon-humanpictos' => 'humanpictos',


			'icon-team' => 'team',


			'icon-package' => 'package',


			'icon-teamwork' => 'teamwork',


			'icon-care' => 'care',


			'icon-handshake' => 'handshake',


			'icon-puzzle' => 'puzzle',


			'icon-networking-29' => 'networking-29',


			'icon-user-1' => 'user-1',


			'icon-user' => 'user',


			'icon-chat' => 'chat',


			'icon-networking-110' => 'networking-110',


			'icon-group1' => 'group1',


			'icon-worldwide1' => 'worldwide1',


			'icon-podium' => 'podium',


			'icon-idea-2' => 'idea-2',


			'icon-laptop-1' => 'laptop-1',


			'icon-target' => 'target',


			'icon-networking1' => 'networking1',


			'icon-idea-1' => 'idea-1',


			'icon-coin-1' => 'coin-1',


			'icon-presentation' => 'presentation',


			'icon-flag' => 'flag',


			'icon-diamond' => 'diamond',


			'icon-like' => 'like',


			'icon-settings1' => 'settings1',


			'icon-ipo' => 'ipo',


			'icon-contract' => 'contract',


			'icon-line-chart' => 'line-chart',


			'icon-coin' => 'coin',


			'icon-idea' => 'idea',


			'icon-hourglass' => 'hourglass',


			'icon-laptop' => 'laptop',


			'icon-money-bag' => 'money-bag',


			'icon-stationery' => 'stationery',


			'icon-growth' => 'growth',


			'icon-agreement' => 'agreement',


			'icon-badge' => 'badge',


			'icon-bar-chart1' => 'bar-chart1',


			'icon-bar-chart-1' => 'bar-chart-1',


			'icon-businessman1' => 'businessman1',


			'icon-businessman-18' => 'businessman-18',


			'icon-businessman-21' => 'businessman-21',


			'icon-businessman-31' => 'businessman-31',


			'icon-businessman-41' => 'businessman-41',


			'icon-businessman-51' => 'businessman-51',


			'icon-businessman-61' => 'businessman-61',


			'icon-businessman-71' => 'businessman-71',


			'icon-businesswoman1' => 'businesswoman1',


			'icon-businesswoman-11' => 'businesswoman-11',


			'icon-businesswoman-21' => 'businesswoman-21',


			'icon-businesswoman-3' => 'businesswoman-3',


			'icon-businesswoman-4' => 'businesswoman-4',


			'icon-chronometer' => 'chronometer',


			'icon-circular-chart' => 'circular-chart',


			'icon-cogwheel' => 'cogwheel',


			'icon-customer-service1' => 'customer-service1',


			'icon-group2' => 'group2',


			'icon-group-1' => 'group-1',


			'icon-group-2' => 'group-2',


			'icon-group-3' => 'group-3',


			'icon-group-4' => 'group-4',


			'icon-head1' => 'head1',


			'icon-head-11' => 'head-11',


			'icon-head-21' => 'head-21',


			'icon-head-31' => 'head-31',


			'icon-hierarchical-structure1' => 'hierarchical-structure1',


			'icon-hierarchical-structure-11' => 'hierarchical-structure-11',


			'icon-hierarchical-structure-21' => 'hierarchical-structure-21',


			'icon-hierarchical-structure-31' => 'hierarchical-structure-31',


			'icon-hierarchical-structure-41' => 'hierarchical-structure-41',


			'icon-hierarchical-structure-5' => 'hierarchical-structure-5',


			'icon-hierarchical-structure-6' => 'hierarchical-structure-6',


			'icon-hierarchical-structure-7' => 'hierarchical-structure-7',


			'icon-hierarchical-structure-8' => 'hierarchical-structure-8',


			'icon-hierarchical-structure-9' => 'hierarchical-structure-9',


			'icon-id-card1' => 'id-card1',


			'icon-line-chart1' => 'line-chart1',


			'icon-loss' => 'loss',


			'icon-magnifying-glass1' => 'magnifying-glass1',


			'icon-magnifying-glass-1' => 'magnifying-glass-1',


			'icon-medal' => 'medal',


			'icon-medal-1' => 'medal-1',


			'icon-medal-2' => 'medal-2',


			'icon-networking2' => 'networking2',


			'icon-networking-111' => 'networking-111',


			'icon-panel1' => 'panel1',


			'icon-paper-plane' => 'paper-plane',


			'icon-percentage' => 'percentage',


			'icon-phonebook' => 'phonebook',


			'icon-phone-call' => 'phone-call',


			'icon-pie-chart1' => 'pie-chart1',


			'icon-pie-chart-1' => 'pie-chart-1',


			'icon-placeholder1' => 'placeholder1',


			'icon-scheme' => 'scheme',


			'icon-scheme-1' => 'scheme-1',


			'icon-scheme-2' => 'scheme-2',


			'icon-settings2' => 'settings2',


			'icon-settings-11' => 'settings-11',


			'icon-settings-21' => 'settings-21',


			'icon-settings-31' => 'settings-31',


			'icon-settings-41' => 'settings-41',


			'icon-shopping-cart' => 'shopping-cart',


			'icon-speech-bubble' => 'speech-bubble',


			'icon-speech-bubble-1' => 'speech-bubble-1',


			'icon-tag' => 'tag',


			'icon-tag-1' => 'tag-1',


			'icon-target1' => 'target1',


			'icon-target-1' => 'target-1',


			'icon-worldwide2' => 'worldwide2',


			'icon-wrench' => 'wrench',


			'icon-badge1' => 'badge1',


			'icon-browser' => 'browser',


			'icon-browser-1' => 'browser-1',


			'icon-businessman2' => 'businessman2',


			'icon-businessman-19' => 'businessman-19',


			'icon-businessman-22' => 'businessman-22',


			'icon-businessman-32' => 'businessman-32',


			'icon-businessman-42' => 'businessman-42',


			'icon-businessman-52' => 'businessman-52',


			'icon-businessman-62' => 'businessman-62',


			'icon-businessman-72' => 'businessman-72',


			'icon-businessman-81' => 'businessman-81',


			'icon-businessman-91' => 'businessman-91',


			'icon-businessman-101' => 'businessman-101',


			'icon-businessman-111' => 'businessman-111',


			'icon-businessman-121' => 'businessman-121',
			'icon-businessman-131' => 'businessman-131',
			'icon-businessman-141' => 'businessman-141',
			'icon-businessmen1' => 'businessmen1',
			'icon-businessmen-11' => 'businessmen-11',
			'icon-businessmen-2' => 'businessmen-2',
			'icon-coin1' => 'coin1',
			'icon-coin-11' => 'coin-11',
			'icon-coin-2' => 'coin-2',
			'icon-coins' => 'coins',
			'icon-coins-1' => 'coins-1',
			'icon-coins-2' => 'coins-2',
			'icon-coins-3' => 'coins-3',
			'icon-contract1' => 'contract1',
			'icon-credit-card' => 'credit-card',
			'icon-dollar-bill' => 'dollar-bill',
			'icon-dollar-bill-1' => 'dollar-bill-1',
			'icon-dollar-symbol' => 'dollar-symbol',
			'icon-dollar-symbol-1' => 'dollar-symbol-1',
			'icon-dollar-symbol-2' => 'dollar-symbol-2',
			'icon-euro' => 'euro',
			'icon-hierarchy' => 'hierarchy',
			'icon-hierarchy-1' => 'hierarchy-1',
			'icon-laptop1' => 'laptop1',
			'icon-laptop-11' => 'laptop-11',
			'icon-laptop-2' => 'laptop-2',
			'icon-laptop-3' => 'laptop-3',
			'icon-laptop-4' => 'laptop-4',
			'icon-magnifying-glass2' => 'magnifying-glass2',
			'icon-money' => 'money',
			'icon-money-1' => 'money-1',
			'icon-money-2' => 'money-2',
			'icon-money-3' => 'money-3',
			'icon-money-4' => 'money-4',
			'icon-money-5' => 'money-5',
			'icon-money-6' => 'money-6',
			'icon-money-7' => 'money-7',
			'icon-money-8' => 'money-8',
			'icon-money-9' => 'money-9',
			'icon-money-10' => 'money-10',
			'icon-money-11' => 'money-11',
			'icon-networking3' => 'networking3',
			'icon-networking-112' => 'networking-112',
			'icon-networking-210' => 'networking-210',
			'icon-networking-31' => 'networking-31',
			'icon-networking-41' => 'networking-41',
			'icon-networking-51' => 'networking-51',
			'icon-payment-method' => 'payment-method',
			'icon-payment-method-1' => 'payment-method-1',
			'icon-payment-method-2' => 'payment-method-2',
			'icon-piggy-bank' => 'piggy-bank',
			'icon-piggy-bank-1' => 'piggy-bank-1',
			'icon-settings3' => 'settings3',
			'icon-shield' => 'shield',
			'icon-tablet' => 'tablet',
		];
	}

	/**
	 * Get icons control default settings.
	 *
	 * Retrieve the default settings of the icons control. Used to return the default
	 * settings while initializing the icons control.
	 *
	 * @since 1.0.0
	 * @access protected
	 *
	 * @return array Control default settings.
	 */
	protected function get_default_settings() {
		return [
			'options' => self::get_icons(),
			'include' => '',
			'exclude' => '',
		];
	}

	/**
	 *  method registers and enqueues scripts and styles used by the control.
	 */
	public function enqueue()
	{
		wp_enqueue_script( 'icomoon-js', CONSUX_TF_ELEMENTOR_URL . 'assets/js/load-select2.js', ['jquery'], '1.0.0' );
	}

	/**
	 * Render icons control output in the editor.
	 *
	 * Used to generate the control HTML in the editor using Underscore JS
	 * template. The variables for the class are available using `data` JS
	 * object.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function content_template() {
		$control_uid = $this->get_control_uid();
		?>
		<div class="elementor-control-field">
			<label for="<?php echo $control_uid; ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<div class="elementor-control-input-wrapper">
				<select id="<?php echo $control_uid; ?>" class="custom-control-icon2" data-setting="{{ data.name }}" data-placeholder="<?php echo __( 'Select Icon', 'elementor' ); ?>">
					<option value=""><?php echo __( 'Select Icon', 'elementor' ); ?></option>
					<# _.each( data.options, function( option_title, option_value ) { #>
						<option value="{{ option_value }}" data-icon="{{ option_value }}">{{{ option_title }}}</option>
						<# } ); #>
				</select>
			</div>
		</div>
		<# if ( data.description ) { #>
			<div class="elementor-control-field-description">{{ data.description }}</div>
			<# } #>
		<?php
	}

}