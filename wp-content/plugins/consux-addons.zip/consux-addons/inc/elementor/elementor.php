<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'CONSUX_Elementor_Widgets' ) )
{
	/**
	 * Main CONSUX_Elementor_Widgets Class
	 *
	 */

	final class CONSUX_Elementor_Widgets {
		/** Singleton *************************************************************/

		private static $_instance = null;

		public static  function instance()
		{
			if ( is_null( self::$_instance ) )
			{
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		public function __construct()
		{
			add_action( 'plugins_loaded', [ $this, 'init' ] );
			add_action( 'wp_footer', [ $this, 'load_photoswipe_popup' ] );
		}

		public function init()
		{
			// Check if Elementor installed and activated
			if ( ! did_action( 'elementor/loaded' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
				return;
			}
			// Register new controls
			require_once( CONSUX_TF_ELEMENTOR_PATH . '/new-controls/new-font-icons.php' );

			// Register new widget category
			add_action( 'elementor/elements/categories_registered', [ $this, 'widget_categories' ] );

			add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
			// Register Widget Styles
			add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );
			// Register Widget Scripts
			add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );
			// load custom font icons on editor
			add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'load_fonts' ] );

			// Add new control
			add_action( 'elementor/controls/controls_registered', [ $this, 'new_controls' ] );
		}

		public function new_controls( $elementor )
		{
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'new-controls/new-font-icons.php' );
			$elementor->register_control( 'flaticon', new Consux_Flaticon_Control() );
			$elementor->register_control( 'icomoon', new Consux_IcoMoon_Control() );
		}

		public function load_fonts()
		{
			wp_enqueue_style( 'flaticon_5', CONSUX_TF_CSS_URL . 'flaticon_5.min.css'  );
			wp_enqueue_style( 'icomoon', CONSUX_TF_CSS_URL . 'icomoon-icons.css'  );
		}

		public function widget_categories(  $elements_manager )
		{
			$elements_manager->add_category(
				'consux-category',
				[
					'title' => __( 'Consux', 'consux' ),
					'icon' => 'fa fa-plug',
				]
			);
		}

		public function widget_styles()
		{
			wp_enqueue_style( 'flaticon_5', CONSUX_TF_CSS_URL . 'flaticon_5.min.css'  );
			wp_enqueue_style( 'icomoon', CONSUX_TF_CSS_URL . 'icomoon-icons.css'  );
			wp_enqueue_style( 'magnific-css', CONSUX_TF_ELEMENTOR_URL . 'assets/css/magnific-popup.css'  );
		}

		public function widget_scripts()
		{
			wp_enqueue_script( 'consux-isotope', CONSUX_TF_ELEMENTOR_URL . 'assets/js/isotope.pkgd.min.js', [ 'jquery' ] );
			wp_enqueue_script( 'consux-slick', CONSUX_TF_ELEMENTOR_URL . 'assets/js/slick.min.js', [ 'jquery' ], '1.0.0', 'true' );
			wp_enqueue_script( 'boostrap-script', CONSUX_TF_ELEMENTOR_URL . 'assets/js/bootstrap.min.js', [ 'jquery' ], '4.1.3', true );
			wp_enqueue_script( 'chart-js', CONSUX_TF_ELEMENTOR_URL . 'assets/js/chart.min.js', [ 'jquery' ] );
			wp_enqueue_script( 'magnific', CONSUX_TF_ELEMENTOR_URL . 'assets/js/jquery.magnific-popup.min.js', [ 'jquery' ] );
			wp_enqueue_script( 'inviewport', CONSUX_TF_ELEMENTOR_URL . 'assets/js/isInViewport.min.js', [ 'jquery' ] );
			wp_enqueue_script( 'widget-elementor-scripts', CONSUX_TF_ELEMENTOR_URL . 'assets/js/scripts.js', [ 'jquery', 'masonry' ] );
		}
		public function init_widgets( $widgets_manager ) {

//			// Include Widget files
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/video-button/video-button.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/chart/chart.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/case-study/case-study.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/accordion/accordion.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/service/service.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/map/map.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/link/link.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/progress/progress.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/testimonial/testimonial.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/member/member.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/icon-box/icon-box.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/pricing/pricing.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/gallery/gallery.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/timeline/timeline.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/countdown/countdown.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/blog/blog.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/images/images.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/image-box/image-box.php' );
			require_once( CONSUX_TF_ELEMENTOR_PATH . 'widgets/list/list.php' );
		}

		public function admin_notice_missing_main_plugin() {

			if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

			$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
				esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'consux' ),
				'<strong>' . esc_html__( 'Elementor Test Extension', 'consux' ) . '</strong>',
				'<strong>' . esc_html__( 'Elementor', 'consux' ) . '</strong>'
			);

			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

		}

		function load_photoswipe_popup()
		{
		?>
		<!-- Root element of PhotoSwipe. Must have class pswp. -->
			<div class="pswp" id="pswp" tabindex="-1" role="dialog" aria-hidden="true">

			<!-- Background of PhotoSwipe. 
				It's a separate element as animating opacity is faster than rgba(). -->
			<div class="pswp__bg"></div>

			<!-- Slides wrapper with overflow:hidden. -->
			<div class="pswp__scroll-wrap">

				<!-- Container that holds slides. 
					PhotoSwipe keeps only 3 of them in the DOM to save memory.
					Don't modify these 3 pswp__item elements, data is added later on. -->
				<div class="pswp__container">
					<div class="pswp__item"></div>
					<div class="pswp__item"></div>
					<div class="pswp__item"></div>
				</div>

				<!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
				<div class="pswp__ui pswp__ui--hidden">

					<div class="pswp__top-bar">

						<!--  Controls are self-explanatory. Order can be changed. -->

						<div class="pswp__counter"></div>

						<button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

						<button class="pswp__button pswp__button--share" title="Share"></button>

						<button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

						<button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

						<!-- Preloader demo https://codepen.io/dimsemenov/pen/yyBWoR -->
						<!-- element will get class pswp__preloader--active when preloader is running -->
						<div class="pswp__preloader">
							<div class="pswp__preloader__icn">
							<div class="pswp__preloader__cut">
								<div class="pswp__preloader__donut"></div>
							</div>
							</div>
						</div>
					</div>

					<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
						<div class="pswp__share-tooltip"></div> 
					</div>

					<button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
					</button>

					<button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
					</button>

					<div class="pswp__caption">
						<div class="pswp__caption__center"></div>
					</div>

				</div>

			</div>

			</div>
		<?php
		}
	}
}