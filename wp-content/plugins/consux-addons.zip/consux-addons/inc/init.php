<?php
if ( ! class_exists( 'Consux_TF_Init' ) )
{
	class Consux_TF_Init
	{
		function __construct()
		{
			add_action( 'admin_enqueue_scripts', [$this, 'admin_scripts'] );
		}

		function admin_scripts()
		{
			wp_enqueue_style( 'admin-flaticon', CONSUX_TF_CSS_URL . 'flaticon_5.min.css' );
		}
	}
}