<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Class register taxonomies and metaboxes
 */

if ( ! class_exists( 'Consux_Register_Service' ) )
{
    class Consux_Register_Service
    {

        /**
         * Consux_Register_Service constructor
         */
        function __construct()
        {
            add_action( 'init', array( $this, 'service' ), 5 );
        }

        /**
         * Register service post type
         */
        function service()
        {
            $labels = array(
                'name'               => _x( 'Services', 'post type general name', 'consux' ),
                'singular_name'      => _x( 'Service', 'post type singular name', 'consux' ),
                'menu_name'          => _x( 'Services', 'admin menu', 'consux' ),
                'name_admin_bar'     => _x( 'Service', 'add new on admin bar', 'consux' ),
                'add_new'            => _x( 'Add New', 'consux' ),
                'add_new_item'       => __( 'Add New Service', 'consux' ),
                'new_item'           => __( 'New Service', 'consux' ),
                'edit_item'          => __( 'Edit Service', 'consux' ),
                'view_item'          => __( 'View Service', 'consux' ),
                'all_items'          => __( 'All Services', 'consux' ),
                'search_items'       => __( 'Search Services', 'consux' ),
                'parent_item_colon'  => __( 'Parent Services:', 'consux' ),
                'not_found'          => __( 'No Services found.', 'consux' ),
                'not_found_in_trash' => __( 'No Services found in Trash.', 'consux' )
            );

            $args = array(
                'labels'             => $labels,
                'description'        => __( 'Description.', 'consux' ),
                'public'             => true,
                'publicly_queryable' => true,
                'menu_icon'          => 'dashicons-heart',
                'show_ui'            => true,
                'show_in_menu'       => true,
                'query_var'          => true,
                'rewrite'            => array( 'slug' => 'service' ),
                'capability_type'    => 'post',
                'has_archive'        => true,
                'hierarchical'       => false,
                'menu_position'      => null,
                'supports'           => array( 'title', 'editor','thumbnail', 'excerpt' )
            );
	        $args = apply_filters( 'consux_service_args', $args );
            register_post_type( 'service', $args );
        }

    }
}