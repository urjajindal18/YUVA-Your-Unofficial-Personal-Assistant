<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Class register taxonomies and metaboxes
 */

if ( ! class_exists( 'Consux_Register_Member' ) )
{
    class Consux_Register_Member
    {

        /**
         * Consux_Register_Member constructor
         */
        function __construct()
        {
            add_action( 'init', array( $this, 'member' ), 5 );
        }

        /**
         * Register member post type
         */
        function member()
        {
            $labels = array(
                'name'               => _x( 'Members', 'post type general name', 'consux' ),
                'singular_name'      => _x( 'Member', 'post type singular name', 'consux' ),
                'menu_name'          => _x( 'Members', 'admin menu', 'consux' ),
                'name_admin_bar'     => _x( 'Member', 'add new on admin bar', 'consux' ),
                'add_new'            => _x( 'Add New', 'consux' ),
                'add_new_item'       => __( 'Add New Member', 'consux' ),
                'new_item'           => __( 'New Member', 'consux' ),
                'edit_item'          => __( 'Edit Member', 'consux' ),
                'view_item'          => __( 'View Member', 'consux' ),
                'all_items'          => __( 'All Members', 'consux' ),
                'search_items'       => __( 'Search Members', 'consux' ),
                'parent_item_colon'  => __( 'Parent Members:', 'consux' ),
                'not_found'          => __( 'No Members found.', 'consux' ),
                'not_found_in_trash' => __( 'No Members found in Trash.', 'consux' )
            );

            $args = array(
                'labels'             => $labels,
                'description'        => __( 'Description.', 'consux' ),
                'public'             => true,
                'publicly_queryable' => true,
                'menu_icon'          => 'dashicons-admin-users',
                'show_ui'            => true,
                'show_in_menu'       => true,
                'query_var'          => true,
                'rewrite'            => array( 'slug' => 'member' ),
                'capability_type'    => 'post',
                'has_archive'        => true,
                'hierarchical'       => false,
                'menu_position'      => null,
                'supports'           => array( 'title', 'editor','thumbnail', 'excerpt' )
            );
	        $args = apply_filters( 'consux_member_args', $args );
            register_post_type( 'member', $args );
        }

    }
}