<?php

/**
 * Function gets services
 * @param $args array argument attributes
 * @return $output string list services
 */
function consux_get_members( $atts )
{

	$args = array(
		'post_type'             =>  'member',
		'post_status'           => 'publish',
		'ignore_sticky_posts'   => 1,
		'posts_per_page'        => $atts['per_page']
	);

	if( is_single( get_the_ID() ) )
	{
		$args['post__not_in'] = array( get_the_ID() );
	}

	$args['orderby'] = $atts['orderby'];
	$args['order']   = $atts['order'];

	$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
	$args['paged'] = $paged;

	$members = new WP_Query( $args );

	if ( $members->have_posts() )
	{

		$output = $members;
	}
	else
	{
		$output = false;
	}

	wp_reset_postdata();

	return $output;
}

/**
 * Function gets services
 * @param $args array argument attributes
 * @return $output string list services
 */
function consux_get_case_study( $atts )
{

	$args = array(
		'post_type'             =>  'case_study',
		'post_status'           => 'publish',
		'ignore_sticky_posts'   => 1,
		'posts_per_page'        => $atts['per_page']
	);

	if( is_single( get_the_ID() ) )
	{
		$args['post__not_in'] = array( get_the_ID() );
	}
	if ( isset( $atts['category'] ) && $atts['category'] )
	{
		$args['tax_query'] =  array(
			array(
				'taxonomy' => 'case_study_categories',
				'terms'    => $atts['category'],
				'field'    => 'slug',
			)
		);
	}

	$args['orderby'] = $atts['orderby'];
	$args['order']   = $atts['order'];

	$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
	$args['paged'] = $paged;

	$services = new WP_Query( $args );

	if ( $services->have_posts() )
	{

		$output = $services;
	}
	else
	{
		$output = false;
	}

	wp_reset_postdata();

	return $output;
}

/**
 * Function get list testimonial categories
 * @return $term Term quots terms
 */
function consux_get_list_case_study_categories()
{
	$cats = array();
	$terms = consux_get_case_study_categories();
	foreach ( $terms as $term )
	{
		$cats[ $term->slug ] = $term->name;
	}
	return $cats;
}

/**
 * Function get list blog categories
 * @return $term Term quots terms
 */
function consux_get_post_categories()
{
	$cats = array();
	$terms = get_categories();
	foreach ( $terms as $term )
	{
		$cats[ $term->slug ] = $term->name;
	}
	return $cats;
}

/**
 * Function get all testimonial categories
 * @return $term Term
 */
function consux_get_case_study_categories()
{
	$terms = get_terms(  array(
		'taxonomy'      =>  'case_study_categories',
		'hide_empty'    =>  true,
		'orderby'       =>  'term_id',
		'order'         => 'DESC'
	) );
	return $terms;
}

function consux_tf_cat_parent_index( $arr, $id ) {
	$len = count( $arr );
	if ( 0 == $len ) {
		return false;
	}
	$id = absint( $id );
	for ( $i = 0; $i < $len; $i++ ) {
		if ( $id == $arr[ $i ][ 'id' ] ) {
			return $i;
		}
	}
	return false;
}

if ( ! function_exists( 'consux_get_mega_menu_setting_default' ) ) :
	/**
	 * Get the default mega menu settings of a menu item
	 *
	 * @return array
	 */
	function consux_get_mega_menu_setting_default() {
		return apply_filters(
			'consux_mega_menu_setting_default',
			array(
				'mega'         => false,
				'icon'         => '',
				'hide_text'    => false,
				'disable_link' => false,
				'content'      => '',
				'width'        => '',
				'border'       => array(
					'left' => 0,
				),
				'background'   => array(
					'image'      => '',
					'color'      => '',
					'attachment' => 'scroll',
					'size'       => '',
					'repeat'     => 'no-repeat',
					'position'   => array(
						'x'      => 'left',
						'y'      => 'top',
						'custom' => array(
							'x' => '',
							'y' => '',
						),
					),
				),
			)
		);
	}
endif;

if ( ! function_exists( 'consux_parse_args' ) ) :
	/**
	 * Recursive merge user defined arguments into defaults array.
	 *
	 * @param array $args
	 * @param array $default
	 *
	 * @return array
	 */
	function consux_parse_args( $args, $default = array() ) {
		$args   = (array) $args;
		$result = $default;

		foreach ( $args as $key => $value ) {
			if ( is_array( $value ) && isset( $result[ $key ] ) ) {
				$result[ $key ] = consux_parse_args( $value, $result[ $key ] );
			} else {
				$result[ $key ] = $value;
			}
		}

		return $result;
	}

endif;

// for mega menu

function tz_addons_recurse_parse_args( $args, $default = array() ) {
$args   = (array) $args;
$result = $default;

foreach ( $args as $key => $value ) {
	if ( is_array( $value ) && isset( $result[ $key ] ) ) {
		$result[ $key ] = tz_addons_recurse_parse_args( $value, $result[ $key ] );
	} else {
		$result[ $key ] = $value;
	}
}

return $result;
}

