<?php
/**
 * Load and register widgets
 *
 * @package
 */

require_once CONSUX_TF_INC_PATH . 'widgets/socials/list-socials.php';
require_once CONSUX_TF_INC_PATH . 'widgets/recent-posts/recent-posts.php';
require_once CONSUX_TF_INC_PATH . 'widgets/case-study.php';

/**
 * Register widgets
 *
 * @since  1.0
 *
 * @return void
 */
function wpf_register_widgets()
{
    register_widget( 'CONSUX_Socials_Widget' );
    register_widget( 'CONSUX_Recent_Posts' );
    register_widget( 'CONSUX_Case_Study' );
}
add_action( 'widgets_init', 'wpf_register_widgets' );