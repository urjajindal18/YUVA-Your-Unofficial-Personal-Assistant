<?php
if ( ! class_exists( 'CONSUX_Case_Study' ) )
{
    /**
     * Class CONSUX_Case_Study create latest tweet widget
     */
    class CONSUX_Case_Study extends WP_Widget
    {
        protected $defaults;

        /**
         * Sets up the widgets name etc
         */
        public function __construct()
        {
            $this->defaults = array(
                'title'         => '',
            );

            $widget_ops = array(
                'classname' => 'wpf_case_study_client_information',
                'description' => __( 'Display Client Information, the information just show on case study page', 'consux' ),
            );
            parent::__construct( 'wpf_case_study_client_information', __( 'Consux Case Study Information', 'consux' ), $widget_ops );
        }

        /**
         * Outputs the content of the widget
         *
         * @param array $args
         * @param array $instance
         */
        public function widget( $args, $instance )
        {
            // outputs the content of the widget
            $instance = wp_parse_args( $instance, $this->defaults );

            echo $args['before_widget'];

            if ( $title = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base ) )
            {
                echo $args['before_title'] . $title . $args['after_title'];
            }
            if  ( 'case_study' == get_post_type() )
            {
                $cs_id = get_the_ID();
                if ( $cs_id )
                {
                    $client_name = consux_get_post_meta( 'mb_client' );
                    $date = consux_get_post_meta( 'mb_date' );
                    $website = consux_get_post_meta( 'mb_website' );
                    ?>
                    <div class="wrapper-content">
                        <div class="client-info client">
                            <span><?php esc_html_e( 'Client: ' ); ?></span>
                            <span><?php echo esc_html( $client_name ); ?></span>
                        </div>
                        <div class="client-info date">
                            <span><?php esc_html_e( 'Date: ' ); ?></span>
                            <span><?php echo esc_html( $date ); ?></span>
                        </div>
                        <div class="client-info website">
                            <span><?php esc_html_e( 'website: ' ); ?></span>
                            <span><?php echo esc_html( $website ); ?></span>
                        </div>
                        <div class="client-info category">
                            <span><?php esc_html_e( 'category: ' ); ?></span>
                            <span>
                            <?php
                            $cats = get_the_terms( $cs_id, 'case_study_categories' );
                            if ( $cats )
                            {
                                $count = 0;
                                foreach ( $cats as $cat )
                                {
                                    $separator = ', ';
                                    if ( $count == count( $cats ) - 1 )
                                    {
                                        $separator = '';
                                    }
                                    echo sprintf( '<a class="cat" href="%s">%s</a>%s', get_term_link( $cat->term_id ), esc_html( $cat->name ), $separator );
                                    $count++;
                                }
                            }
                            ?>
                            </span>
                        </div>
                        <div class="client-info client-social">
                            <span><?php esc_html_e( 'Share: ' ); ?></span>
                            <span>
                            <?php
                            $socials = array( 'facebook', 'google_plus', 'twitter', 'pinterest', 'skypet' );
                            foreach ( $socials as $social )
                            {
                                $val = consux_get_post_meta( $social );
                                if ( $val )
                                {
                                    if ( 'google_plus' == $social )
                                    {
                                        $social = 'google-plus';
                                    }
                                ?>
                                    <a href="<?php echo esc_url( $val ); ?>" class="social"><i class="fa fa-<?php echo esc_attr( $social )?>" aria-hidden="true"></i></a>
                                <?php
                                }
                            }
                            ?>
                            </span>
                        </div>
                        <?php
                        $btn_1_url = consux_get_post_meta( 'mb_button_url_1' );
                        $btn_2_url = consux_get_post_meta( 'mb_button_url_2' );

                        if ( $btn_1_url )
                        {
                        ?>
                            <a class="btn-action" href="<?php echo esc_url( $btn_1_url ); ?>"><img src="<?php echo CONSUX_TF_URL . 'img/pdf.png'; ?>"><?php esc_html_e( 'PDF. Download', 'consux' ); ?></a>
                         <?php
                        }
                        if ( $btn_2_url )
                        {
                            ?>
                            <a class="btn-action" href="<?php echo esc_url( $btn_2_url ); ?>"><img src="<?php echo CONSUX_TF_URL . 'img/doc.png'; ?>"><?php esc_html_e( 'DOC. Download', 'consux' ); ?></a>
                            <?php
                        }
                        ?>
                    </div>
                    <?php
                }
            }
            echo $args['after_widget'];
        }

        /**
         * Outputs the options form on admin
         *
         * @param array $instance The widget options
         */
        public function form( $instance )
        {
            $instance = wp_parse_args( $instance, $this->defaults );
            ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'consux' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
            </p>
            <?php
        }

        /**
         * Processing widget options on save
         *
         * @param array $new_instance The new options
         * @param array $old_instance The previous options
         *
         * @return array
         */
        public function update( $new_instance, $old_instance ) {
            $new_instance['title']         = strip_tags( $new_instance['title'] );
            return $new_instance;
        }
    }
}