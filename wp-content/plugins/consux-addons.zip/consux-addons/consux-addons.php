<?php
/**
 * Plugin Name: Consux Addons
 * Plugin URI: http://themecitizen.com/
 * Description: The plugin contains the important functions use for theme
 * Version: 1.0
 * Author: Themecitizen
 * Author URI: http://themecitizen.com/
 */

define( 'CONSUX_TF_PATH', plugin_dir_path( __FILE__ ) );
define( 'CONSUX_TF_URL', plugin_dir_url( __FILE__ ) );

define( 'CONSUX_TF_INC_PATH', trailingslashit( CONSUX_TF_PATH . 'inc' ) );
define( 'CONSUX_TF_INC_URL', trailingslashit( CONSUX_TF_URL . 'inc' ) );

define( 'CONSUX_TF_CSS_URL', trailingslashit( CONSUX_TF_URL . 'css' ) );
define( 'CONSUX_TF_JS_URL', trailingslashit( CONSUX_TF_URL . 'js' ) );

define( 'CONSUX_TF_ELEMENTOR_PATH', trailingslashit( CONSUX_TF_INC_PATH . 'elementor' ) );
define( 'CONSUX_TF_ELEMENTOR_URL', trailingslashit( CONSUX_TF_INC_URL . 'elementor' ) );

define( 'CONSUX_TF_VERSION', '1.0.0' );

require CONSUX_TF_INC_PATH . 'template-tag.php';
require CONSUX_TF_INC_PATH . 'mega-menu/menus.php';
require CONSUX_TF_INC_PATH . 'widgets/widgets.php';
require CONSUX_TF_INC_PATH . '/case_study/class-consux-register-case-study.php';
new Consux_Register_Case_Study();
require CONSUX_TF_INC_PATH . '/service/class-consux-register-service.php';
new Consux_Register_Service();
require CONSUX_TF_INC_PATH . '/member/class-consux-register-member.php';
new Consux_Register_Member();

require CONSUX_TF_ELEMENTOR_PATH . 'utils.php';
require CONSUX_TF_ELEMENTOR_PATH . 'elementor.php';
CONSUX_Elementor_Widgets::instance();

require CONSUX_TF_INC_PATH . 'init.php';
new Consux_TF_Init();

function consux_register_extend_elements()
{
	add_image_size( 'consux-recent-post-thumbnail-widget', 60, 60, true );
	add_image_size( 'consux-product-gallery-thumbnail', 183, 152, true );
}
add_action( 'after_setup_theme', 'consux_register_extend_elements' );